import os
from tile_getter import TileGetter

PATH = 'assets'
IMAGE_PATH = os.path.join(PATH, 'images')


class Tile:
    def __init__(self, position, tile_number, scale, tile_set=0):
        """
        Basic tile class
        :param (int, int) position: The position of the Tile
        :param int tile_number: The tile number to load from the sprite sheet
        :param int scale: The scale of the tile
        """
        self.surface = TileGetter.get_tile(tile_number, scale, tile_set)  # Load surface
        self.rect = self.surface.get_rect(topleft=position)  # Get rect and set position

        self.remove = False  # Set to true to remove from the game

    def hit(self, sounds):  # This is implemented by children, basic tiles don't do anything when hit
        pass

    def update(self):  # Basic tiles don't have anything to update
        pass

    def render(self, surface, camera):
        """
        Render the tile
        :param Surface surface: The surface to blit to
        :param Camera camera:  Camera refernce
        :return: None
        """
        if self.rect.colliderect(camera.rect):  # Blit if on the screen
            surface.blit(self.surface, self.rect.move(-camera.offset, 0))
