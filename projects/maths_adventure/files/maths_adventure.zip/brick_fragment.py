import os
import pygame

PATH = 'assets'
IMAGE_PATH = os.path.join(PATH, 'images')


class BrickFragment:
    def __init__(self, position, velocity, scale):
        """
        A fragment from a brick which is hit
        :param (int, int) position: The position of the fragment
        :param (float, float) velocity: The fragment's velocity
        :param int scale: The scale of the fragment
        """
        self.surface = pygame.image.load(os.path.join(IMAGE_PATH, 'brick_fragment.png')).convert_alpha()  # Load image
        self.surface = pygame.transform.scale(self.surface, (self.surface.get_width() * scale,  # Scale image
                                                             self.surface.get_height() * scale))
        self.rect = self.surface.get_rect(topleft=position)  # Get rect and set position

        self.velocity = pygame.math.Vector2()  # Create velocity vector
        self.velocity.xy = velocity  # Set velocity
        self.gravity = 1.5  # Set gravity

    def update(self):
        """
        Update the fragment
        :return: None
        """
        self.velocity.y += self.gravity  # Increase velocity by gravity
        self.rect.move_ip(self.velocity)  # Move the fragment's rect by its velocity

    def render(self, surface, camera):
        """
        Render the fragment to the surface
        :param Surface surface: The surface to render the fragment to
        :param Camera camera: Reference to the camera
        :return: None
        """
        surface.blit(self.surface, self.rect.move(-camera.offset, 0))  # Blit with the camera's offset
