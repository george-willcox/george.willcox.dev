import pygame
from tile import Tile
from text import Text


class AnswerInput(Tile):
    def __init__(self, position, scale, tile_set=0):
        """
        An answer input
        :param (int, int) position: The position of the brick
        :param int scale: The block's scale
        :param int tile_set: The tile set to use
        """
        super().__init__(position, 7, scale, tile_set)  # Initialise the tile

        self.velocity = pygame.math.Vector2()  # Create velocity
        self.offset = 0  # Set offset
        self.hit_force = 8  # Set hit force
        self.spring_force = 2  # Set spring force, acts as a retarding force

        self.been_hit = False  # Has the block been hit?
        self.reset = False  # reset flag

        self.value = 0
        self.value_text = Text(position, str(self.value), (255, 255, 255), font='Fixedsys500c.ttf', anchor='center')

        self.hide = False

    def reset_value(self, value):
        """
        Reset the value of the block
        :param value: The numerical value to set
        :return: None
        """
        self.value = value  # Update variable
        self.value_text.set_text(str(self.value))  # Change the visible text

        self.reset = False

    def hit(self, sounds):
        """
        Called when hit
        :param dict sounds: Sound effect dict
        :return: None
        """
        sounds['bump'].play()  # Play bump sound
        if not self.been_hit:  # If it hasn't been hit
            self.been_hit = True  # It's been hit
            self.velocity.y = -self.hit_force  # Set y velocity to hit force

    def update(self):
        """
        Update the block
        :return: None
        """
        if self.been_hit:  # Been hit?
            if self.offset <= 0:  # If above where it started
                self.velocity.y += self.spring_force  # Increase velocity by the spring force

                self.offset += self.velocity.y  # Increase the offset by the y velocity

            if self.offset > 0:  # If below where started
                # Set forces, velocity and offset to 0
                self.reset = True
                self.been_hit = False
                self.offset = 0
                self.velocity.y = 0

    def render(self, surface, camera):
        """
        Render brick to surface
        :param Surface surface: Surface to blit to
        :param Camera camera: Camera object
        :return: None
        """
        if self.rect.colliderect(camera.rect):  # If on the screen
            surface.blit(self.surface, self.rect.move(-camera.offset, self.offset))  # Blit with offset

            if not self.hide:  # If not hidden, show the value text
                self.value_text.set_pos(self.rect.move(-camera.offset, self.offset).center)
                self.value_text.render(surface)
