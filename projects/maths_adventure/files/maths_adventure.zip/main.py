import os
import sys
import pygame
import scenes
from pygame.locals import *

# Initialise pygame
pygame.init()
pygame.mixer.pre_init(44100, -16, 3, 4096)

# Get paths
PATH = 'assets'
IMAGE_PATH = os.path.join(PATH, 'images')
SOUND_PATH = os.path.join(PATH, 'sounds')

# Play music
pygame.mixer.music.load(os.path.join(SOUND_PATH, 'main_theme.ogg'))

# Initialise display mode
WIDTH = 896
HEIGHT = 672
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
# Get clock and set FPS
CLOCK = pygame.time.Clock()
FPS = 60

# Load and set icon
ICON = pygame.image.load(os.path.join(IMAGE_PATH, 'icon.png')).convert_alpha()
ICON = pygame.transform.scale(ICON, (32, 32))
pygame.display.set_icon(ICON)
pygame.display.set_caption('Maths Adventure')  # Set caption


def main():
    # Initialise scene manager
    scene_manager = scenes.SceneManager(SCREEN)
    scene_manager.add_scenes(scenes.MenuScene, scenes.InstructionScene, scenes.GameScene, scenes.WinScene)
    scene_manager.set_scene('menu')

    # Main loop
    while True:
        # Handle quitting
        events = pygame.event.get()
        for event in events:
            if event.type == QUIT:
                pygame.quit()
                sys.exit()

        # Update scene manager
        scene_manager.update()
        scene_manager.render(SCREEN)  # Render the current scene to the screen

        pygame.display.update()  # Update the display
        CLOCK.tick(FPS)  # Limit the FPS


if __name__ == '__main__':
    main()  # Run main method
