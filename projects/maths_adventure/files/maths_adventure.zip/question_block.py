from hit_brick import HitBrick
from tile_getter import TileGetter


class QuestionBlock(HitBrick):
    def __init__(self, position, scale, contents, tile_set=0):
        """
        A question block
        :param (int, int) position: The position of the question bloc
        :param int scale: The scale of the tile
        :param Object contents: The contents of the block
        :param int tile_set: The tile set to use
        """
        super().__init__(position, scale, contents, tile_set)  # Initialise parent

        self.frames = [TileGetter.get_tile(frame, scale) for frame in (8, 9, 10, 9)]  # Get frames
        self.frame = 0  # Current frame number

    def render(self, surface, camera):
        """
        Render the block
        :param Surface surface: The surface to blit to
        :param Camera camera: Camera reference
        :return: None
        """
        # Increment frame number
        if self.frame < 1:  # Increment slower on frame 0
            self.frame += 0.02
        else:
            self.frame += 0.15

        self.frame %= len(self.frames)  # Loop back around

        if self.rect.colliderect(camera.rect):  # If on the screen
            if self.been_hit:  # If hit
                frame = self.hit_surface  # Render the hit block
            else:
                frame = self.frames[int(self.frame)]  # Otherwise render the current frame

            surface.blit(frame, self.rect.move(-camera.offset, self.offset))  # Blit the block with the given offset
