import random


class Question:
    def __init__(self, val_range=(1, 10), num_options=4):
        """
        Data stucture to hold generated maths questions.
        Supports basic addition and subtraction
        :param val_range: The range of values chosen for the inputs
        :param num_options: The number of choices
        """
        self.type = random.choice(['add', 'sub'])  # Choose either addition or subtraction

        self.a = random.randint(*val_range)  # Choose the first value
        self.b = random.randint(*val_range)  # Choose the second value

        # Calculate the answer
        if self.type == 'add':
            self.ans = self.a + self.b
        elif self.type == 'sub':
            if self.a < self.b:  # Ensure subtraction is always positive
                a = self.b
                self.b = self.a
                self.a = a

            self.ans = self.a - self.b

        # Generate 4 different options
        self.options = [self.ans]
        while len(self.options) < num_options:
            num = random.randint(0, val_range[1] * 2)
            if num not in self.options:  # No two options can be the same
                self.options.append(num)

        random.shuffle(self.options)  # Put the options in a random order
