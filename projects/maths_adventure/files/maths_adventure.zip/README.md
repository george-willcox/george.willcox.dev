Project Name: Maths Adventure
Author: George Willcox
Version: 2.4
Date: 08/04/2020
Dependencies: Python 3.x
              pygame 1.9.4
Contact: georgewillcox@outlook.com

To run the project, please run the `main.py` file