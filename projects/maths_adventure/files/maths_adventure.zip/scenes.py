import os
import sys
import pygame
from player import Player
from camera import Camera
from brick import Brick
from hit_brick import HitBrick
from block_coin import BlockCoin
from apple import Apple
from map_loader import MapLoader
from sound_loader import load_sounds
from pause import Pause
from text import Text
from button import Button
from abc import ABC, abstractmethod
from pygame.locals import *

PATH = 'assets'
SOUND_PATH = os.path.join(PATH, 'sounds')


def quit_game():
    """
    Quits the game when called
    :return: None
    """
    pygame.quit()
    sys.exit()


class SceneManager:
    def __init__(self, screen):
        """
        Manages the scenes
        :param Surface screen: Reference to the screen
        """
        self.screen = screen  # Sets the screen
        self.scenes = {}  # Initialises a dictionary for the scenes
        self.current_scene = None  # There is no current scene

        self.empty_colour = (0, 0, 0)  # The colour to display if no scene is loaded

    def __getitem__(self, key):
        return self.scenes[key]

    def add_scenes(self, *scenes):
        """
        Adds a scene to the manager
        :param list SceneBase scenes: The scenes to be added
        :return: None
        """
        for scene in scenes:
            self.scenes[scene.name] = scene(self)  # Create entry in dict for each scene

    def set_scene(self, scene_name):
        """
        Change the scene to the one given
        :param scene_name: The name of the scene to switch to
        :return: None
        """
        if self.current_scene is not None:
            self.current_scene.stop()  # Call the stop method on the current scene
        self.current_scene = self.scenes[scene_name]  # Change the current scene
        self.current_scene.start()  # Call the start method of the new scene

    def update(self):
        """
        Update the current scene
        :return: None
        """
        if self.current_scene is not None:
            self.current_scene.update()

    def render(self, surface):
        """
        Render the current scene to the given surface
        :param Surface surface: The surface to render to
        :return: None
        """
        if self.current_scene is not None:
            self.current_scene.render(surface)  # Render the scene if there is one

        else:
            surface.fill(self.empty_colour)  # Otherwise fill with the empty colour


class SceneBase(ABC):  # An abstract class that scenes inherit from
    @abstractmethod
    def start(self):
        pass

    @abstractmethod
    def stop(self):
        pass

    @abstractmethod
    def update(self):
        pass

    @abstractmethod
    def render(self, surface):
        pass


class MenuScene(SceneBase):
    name = 'menu'

    def __init__(self, scene_manager):
        """
        The menu scene
        :param SceneManager scene_manager: Reference to the scene manager
        """
        self.scene_manager = scene_manager
        screen_size = self.scene_manager.screen.get_size()

        # Background colour for each tile set
        self.background_colour = [(107, 140, 255), (0, 0, 0), (0, 0, 0)]

        # Set title text
        self.title = Text((screen_size[0] / 2, 100), 'MATHS ADVENTURE', (255, 255, 255), 64, 'Fixedsys500c.ttf',
                          'center')

        # Set button rects
        start_rect = (screen_size[0] * 0.25, screen_size[1] * 0.65, screen_size[0] * 0.2, screen_size[1] * 0.1)
        instrution_rect = (screen_size[0] * 0.35, screen_size[1] * 0.8, screen_size[0] * 0.3, screen_size[1] * 0.1)
        quit_rect = (screen_size[0] * 0.55, screen_size[1] * 0.65, screen_size[0] * 0.2, screen_size[1] * 0.1)
        # Create button objects
        self.start_button = Button(start_rect, 'START', 48, 'Fixedsys500c.ttf',
                                   (128, 128, 128), (148, 148, 148), (100, 100, 100), (255, 255, 255),
                                   scene_manager.set_scene, 'game')
        self.instruction_button = Button(instrution_rect, 'INSTRUCTIONS', 36, 'Fixedsys500c.ttf',
                                         (128, 128, 128), (148, 148, 148), (100, 100, 100), (255, 255, 255),
                                         scene_manager.set_scene, 'instruction')
        self.quit = Button(quit_rect, 'QUIT', 48, 'Fixedsys500c.ttf',
                           (128, 128, 128), (148, 148, 148), (100, 100, 100), (255, 255, 255), quit_game)

        # Create a map loader object
        self.map_loader = MapLoader()
        # Load in the menu level
        data = self.map_loader.load_map(file_name='menu.lvl')
        self.tiles, self.enemies, self.coins, self.decor, _, self.world_size = data

        # Create a camera object
        self.camera = Camera(self.world_size[0], screen_size)

    def start(self):
        pass

    def stop(self):
        pass

    def update(self):
        """
        Update the two buttons
        :return: None
        """
        # Get the mouse position
        mouse_pos = pygame.mouse.get_pos()

        self.start_button.update(mouse_pos)
        self.instruction_button.update(mouse_pos)
        self.quit.update(mouse_pos)

    def render(self, surface):
        """
        Render the menu screen
        :param Surface surface: The surface to render to
        :return: None
        """
        # Fill in background colour
        surface.fill(self.background_colour[self.map_loader.level])

        # Render all static objects
        for obj in self.decor + self.coins + self.enemies + self.tiles:
            obj.render(surface, self.camera)

        # Render buttons and text
        self.start_button.render(surface)
        self.instruction_button.render(surface)
        self.quit.render(surface)
        self.title.render(surface)


class InstructionScene(SceneBase):
    name = 'instruction'

    def __init__(self, scene_manager):
        """
        The win scene
        :param SceneManager scene_manager: Reference to the scene manager
        """
        self.scene_manager = scene_manager
        screen_size = self.scene_manager.screen.get_size()

        # The background colour
        self.background_colour = 107, 140, 255

        # Set title
        self.title = Text((screen_size[0] / 2, 100), 'INSTRUCTIONS', (255, 255, 255), 64, 'Fixedsys500c.ttf', 'center')

        # Set text
        self.text = [Text((screen_size[0] / 2, screen_size[1] * 0.4), 'USE THE ARROW KEYS TO MOVE',
                          (255, 255, 255), 32, 'Fixedsys500c.ttf', 'center'),
                     Text((screen_size[0] / 2, screen_size[1] * 0.45), 'PRESS SLASH (/) OR DOWN TO RUN',
                          (255, 255, 255), 32, 'Fixedsys500c.ttf', 'center'),
                     Text((screen_size[0] / 2, screen_size[1] * 0.55), 'COLLECT COINS FOR POINTS',
                          (255, 255, 255), 32, 'Fixedsys500c.ttf', 'center'),
                     Text((screen_size[0] / 2, screen_size[1] * 0.6), 'STOMP ON ENEMIES AND AVOID HAZARDS',
                          (255, 255, 255), 32, 'Fixedsys500c.ttf', 'center'),
                     Text((screen_size[0] / 2, screen_size[1] * 0.65), 'AT THE END OF THE STAGE DO MATHS',
                          (255, 255, 255), 32, 'Fixedsys500c.ttf', 'center')]

        # Set button rects
        menu_rect = (screen_size[0] * 0.40, screen_size[1] * 0.8, screen_size[0] * 0.2, screen_size[1] * 0.1)
        # Create buttons
        self.menu = Button(menu_rect, 'MENU', 48, 'Fixedsys500c.ttf',
                           (128, 128, 128), (148, 148, 148), (100, 100, 100), (255, 255, 255), scene_manager.set_scene,
                           'menu')

    def start(self):
        pass

    def stop(self):
        pass

    def update(self):
        """
        Called every frame
        :return: None
        """
        # Get the mouse position
        mouse_pos = pygame.mouse.get_pos()

        self.menu.update(mouse_pos)

    def render(self, surface):
        """
        Render the instruction scene
        :param Surface surface: The surface to render to
        :return: None
        """
        # Fill background colour
        surface.fill(self.background_colour)

        # Render everything in the scene
        self.menu.render(surface)
        self.title.render(surface)

        for text in self.text:
            text.render(surface)


class GameScene(SceneBase):
    name = 'game'

    def __init__(self, scene_manager):
        """
        The scene containing the main game
        :param SceneManager scene_manager: Reference to the scene manager
        """
        self.scene_manager = scene_manager
        screen_size = self.scene_manager.screen.get_size()

        # Set the background colour for the different tile sets
        self.background_colour = [(107, 140, 255), (0, 0, 0), (0, 0, 0)]

        # Create a new map loader object
        self.map_loader = MapLoader()

        # Declare variables
        self.tiles = None
        self.enemies = None
        self.coins = None
        self.decor = None
        self.question = None
        self.world_size = None

        # Create new camera object
        self.camera = Camera(0, screen_size)

        # Create new player object
        self.player = Player()
        # Initialise object arrays
        self.brick_fragments = []
        self.block_coins = []
        self.apples = []

        # Set all text on screen
        # Labels
        self.text = {'score': Text((50, 20), 'Score', (255, 255, 255), 36, 'Fixedsys500c.ttf',
                                   'topleft'),
                     'lives': Text((screen_size[0] / 2, 20), 'Lives', (255, 255, 255), 36, 'Fixedsys500c.ttf',
                                   'midtop'),
                     'coins': Text((screen_size[0] - 50, 20), 'Coins', (255, 255, 255), 36, 'Fixedsys500c.ttf',
                                   'topright')}

        # Values
        self.text_val = {'score': Text((self.text['score'].rect.centerx, 60), str(self.player.score), (255, 255, 255),
                                       36, 'Fixedsys500c.ttf', 'midtop'),
                         'lives': Text((self.text['lives'].rect.centerx, 60), str(self.player.lives), (255, 255, 255),
                                       36, 'Fixedsys500c.ttf', 'midtop'),
                         'coins': Text((self.text['coins'].rect.centerx, 60), str(self.player.coins), (255, 255, 255),
                                       36, 'Fixedsys500c.ttf', 'midtop')}

        # Create pause object
        self.pause = Pause(screen_size, scene_manager)
        self.esc_down = False  # Flag for whether ESC is pressed down

        # Text to display on loading screen
        self.loading_text = Text((20, screen_size[1] - 20), 'LOADING . . .', (255, 255, 255), 36, 'Fixedsys500c.ttf',
                                 'bottomleft')

        # Get sounds
        self.sounds = load_sounds()

        self.dead = False  # Dead flag
        self.death_timer = 0  # Delay from dying to restarting

        self.num_levels = 3  # The number of levels in the game

    def start(self):
        """
        Called each time scene is opened
        :return: None
        """
        # Clear the player score
        self.player.clear_score()

        # Display loading screen
        self.scene_manager.screen.fill(self.background_colour[self.map_loader.level])
        self.loading_text.render(self.scene_manager.screen)
        pygame.display.update()

        # Reset the map
        self.tiles, self.enemies, self.coins, self.decor, self.question, self.world_size = self.map_loader.load_map(0)
        # Reset all game values, do not load map again
        self.reset(False)

    def reset(self, load=True, next_level=False):
        """
        Reset game values
        :param bool load: Reload the level?
        :param bool next_level: Flag for when starting new level
        :return: None
        """
        if load:
            # Display loading screen
            self.scene_manager.screen.fill(self.background_colour[self.map_loader.level])
            self.loading_text.render(self.scene_manager.screen)
            pygame.display.update()

            # Load map
            data = self.map_loader.reset_map()
            self.tiles, self.enemies, self.coins, self.decor, self.question, self.world_size = data

        # Reset camera world width
        self.camera.set_world_width(self.world_size[0])

        # Reset game values
        self.player.reset(next_level)
        self.player.reset_score()
        self.camera.update(self.player)
        self.brick_fragments = []
        self.block_coins = []
        self.apples = []
        self.dead = False
        self.death_timer = 200
        self.pause.paused = False

        # Play the music
        pygame.mixer.music.play(-1, 0.0)

    def stop(self):
        """
        Called each time the scene is left
        :return: None
        """
        # Stop any music that is playing
        pygame.mixer.music.stop()

        # Stop all sound effects
        for sound in self.sounds.values():
            sound.stop()

    def update(self):
        """
        Called every frame
        :return: None
        """
        # Get pressed keys
        keys = pygame.key.get_pressed()

        # Update the pause object
        self.pause.update()

        # Toggle pause with ESC
        if keys[K_ESCAPE]:
            if not self.esc_down:  # Cannot hold down ESC
                self.esc_down = True
                self.pause.toggle()

        else:
            self.esc_down = False

        # When playing the game
        if not self.pause.paused:
            if self.dead:  # If the player has died
                # Update their y position and velocity
                self.player.rect.y += self.player.velocity.y
                self.player.velocity.y += self.player.gravity
                # Decrement death timer
                self.death_timer -= 1

                # Once death timer runs out, reset the level
                if self.death_timer == 0:
                    self.reset()
                    self.player.lives = 3

            else:  # Otherwise update everything
                self.question.update(self.player, self.sounds)

                self.player.update(self.tiles, self.enemies, self.sounds, self.world_size[0])
                self.camera.update(self.player)

                tiles_to_remove = []
                for tile in self.tiles:
                    tile.update()

                    if isinstance(tile, HitBrick):  # If brick is hit, release contents
                        if tile.been_hit:
                            if tile.contents is not None:
                                if tile.contents is BlockCoin:
                                    self.player.add_coin(self.sounds)
                                    self.block_coins.append(tile.contents(tile.rect.midtop))

                                elif tile.contents is Apple:
                                    self.apples.append(tile.contents(tile.rect.center, tile))

                                tile.contents = None

                    if tile.remove:  # If any tiles need removing, add to queue to do so
                        tiles_to_remove.append(tile)

                # Remove all tiles in remove queue
                for tile in tiles_to_remove:
                    # If a brick is removed, spawn brick fragments
                    if isinstance(tile, Brick):
                        self.brick_fragments += tile.fragments

                    self.tiles.remove(tile)

                # Update coins
                for coin in self.coins:
                    coin.update(self.player, self.sounds)

                # Remove collected coins
                self.coins = list(filter(lambda x: not x.collected, self.coins))

                # Kill the player when they have no lives or fall out of the world
                if self.player.lives <= 0 or self.player.rect.top > self.world_size[1]:
                    # Stop all music and sounds
                    pygame.mixer.music.stop()
                    for sound in self.sounds.values():
                        sound.stop()

                    # Play death effect
                    self.sounds['death'].play()
                    self.dead = True  # Set dead flag
                    # Causes the player to jump up in the air when dead
                    self.player.velocity.y = -self.player.jump_force

            # Update enemies
            for enemy in self.enemies:
                enemy.update(self.tiles)

            # Update brick fragments
            for fragment in self.brick_fragments:
                fragment.update()

            # Remove all brick fragments that have fallen out of the world
            self.brick_fragments = list(filter(lambda x: x.rect.top <= self.world_size[1], self.brick_fragments))

            # Update all coins from blocks
            for coin in self.block_coins:
                coin.update()

            # Remove all necessary block coins
            self.block_coins = list(filter(lambda x: x.y_offset <= 0, self.block_coins))

            # Update apples
            for apple in self.apples:
                apple.update(self.player, self.sounds)

            # Remove all collected apples
            self.apples = list(filter(lambda x: not x.collected, self.apples))

            # Update display text
            self.text_val['score'].set_text(str(self.player.score))
            self.text_val['lives'].set_text(str(self.player.lives))
            self.text_val['coins'].set_text(str(self.player.coins))

            # Next level condition
            if self.player.rect.left > self.world_size[0]:
                # Get next level number
                next_level = self.map_loader.level + 1
                if next_level == self.num_levels:  # If there are no more levels, win the game
                    self.scene_manager.set_scene('win')

                else:
                    # Reset game with the next level's map
                    self.player.next_level()
                    data = self.map_loader.load_map(next_level)
                    self.tiles, self.enemies, self.coins, self.decor, self.question, self.world_size = data
                    self.reset(False, True)

    def render(self, surface):
        """
        Render the game
        :param Surface surface: The surface to render to
        :return: None
        """
        # Fill background based on current level
        surface.fill(self.background_colour[self.map_loader.level])

        # Render all objects
        for obj in self.decor + self.coins + self.enemies + self.block_coins + self.apples + self.tiles + [self.player, self.question] + self.brick_fragments:
            obj.render(surface, self.camera)

        # Render text
        for text in self.text.keys():
            self.text[text].render(surface)
            self.text_val[text].render(surface)

        # Render the pause screen
        self.pause.render(surface)


class WinScene(SceneBase):
    name = 'win'

    def __init__(self, scene_manager):
        """
        The win scene
        :param SceneManager scene_manager: Reference to the scene manager
        """
        self.scene_manager = scene_manager
        screen_size = self.scene_manager.screen.get_size()

        # The background colour
        self.background_colour = (0, 0, 0)

        # Set title
        self.title = Text((screen_size[0] / 2, 100), 'YOU WIN', (255, 255, 255), 64, 'Fixedsys500c.ttf', 'center')

        # Set score text
        self.score = Text((screen_size[0] / 2, screen_size[1] * 0.4), 'SCORE: 0', (255, 255, 255), 32,
                          'Fixedsys500c.ttf', 'center')
        self.coins = Text((screen_size[0] / 2, screen_size[1] * 0.45), 'COINS: 0', (255, 255, 255), 32,
                          'Fixedsys500c.ttf', 'center')

        # Set button rects
        menu_rect = (screen_size[0] * 0.25, screen_size[1] * 0.65, screen_size[0] * 0.2, screen_size[1] * 0.1)
        quit_rect = (screen_size[0] * 0.55, screen_size[1] * 0.65, screen_size[0] * 0.2, screen_size[1] * 0.1)
        # Create buttons
        self.menu = Button(menu_rect, 'MENU', 48, 'Fixedsys500c.ttf',
                           (128, 128, 128), (148, 148, 148), (100, 100, 100), (255, 255, 255), scene_manager.set_scene,
                           'menu')
        self.quit = Button(quit_rect, 'QUIT', 48, 'Fixedsys500c.ttf',
                           (128, 128, 128), (148, 148, 148), (100, 100, 100), (255, 255, 255), quit_game)

        # Load end game sound
        self.end_game_sound = pygame.mixer.Sound(os.path.join(SOUND_PATH, 'end of game.ogg'))

    def start(self):
        """
        Called every time the scene is entered
        :return: None
        """
        # Play music
        pygame.mixer.music.stop()
        self.end_game_sound.play()

        # Update score text
        score = self.scene_manager['game'].player.score
        coins = self.scene_manager['game'].player.coins
        self.score.set_text('SCORE: ' + str(score))
        self.coins.set_text('COINS: ' + str(coins))

    def stop(self):
        """
        Called upon leaving the scene
        :return:
        """
        # Stop the sound effect
        self.end_game_sound.stop()

    def update(self):
        """
        Called every frame
        :return: None
        """
        # Get the mouse position
        mouse_pos = pygame.mouse.get_pos()

        self.menu.update(mouse_pos)
        self.quit.update(mouse_pos)

    def render(self, surface):
        """
        Render the win scene
        :param Surface surface: The surface to render to
        :return: None
        """
        # Fill background colour
        surface.fill(self.background_colour)

        # Render everything in the scene
        self.menu.render(surface)
        self.score.render(surface)
        self.coins.render(surface)
        self.quit.render(surface)
        self.title.render(surface)
