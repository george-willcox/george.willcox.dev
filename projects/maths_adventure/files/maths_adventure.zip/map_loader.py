import os
import pygame
from enemy import Enemy
from tile import Tile
from brick import Brick
from coin import Coin
from question_block import QuestionBlock, HitBrick
from block_coin import BlockCoin
from apple import Apple
from question_manager import QuestionManager
from answer_input import AnswerInput
from lava import Lava

PATH = 'assets'
LEVEL_PATH = os.path.join(PATH, 'levels')
SOUND_PATH = os.path.join(PATH, 'sounds')

music_files = ['main_theme.ogg', 'underground.ogg', 'castle.ogg']


class MapLoader:
    def __init__(self, scale=3):
        """
        Class for loading the map
        :param int scale: The scale of the tiles
        """
        self.scale = scale  # Store scale
        self.tile_size = (16, 16)  # Determine tile size
        self.tile_list = []
        self.level_data = []

        self.world_size = (0, 0)  # Placeholder for world size

        self.level = 0  # Current level number

    def load_map(self, level_number=0, file_name=None):
        """
        Load in the game map
        :param int level_number: The level number to load
        :param str file_name: Name of file to load, takes priority over level number
        :return (list Tile, list Enemy, list Coin (int, int)): The tile list, the enemies, the coins, and the world size
        """
        if file_name is None:
            file_name = 'level ' + str(level_number) + '.lvl'
        self.level = level_number
        f = open(os.path.join(LEVEL_PATH, file_name), 'r')  # Open the level file
        data = f.read()  # Read the data
        f.close()  # Close the file
        self.level_data = data.split('\n')  # Split into list on newlines
        self.world_size = (len(self.level_data[0]) * self.tile_size[0] * self.scale,  # Calculate the world size
                           len(self.level_data) * self.tile_size[1] * self.scale)

        # Play music
        pygame.mixer.music.load(os.path.join(SOUND_PATH, music_files[level_number]))

        return self.reset_map()  # Loads the map

    def reset_map(self):
        """
        Reloads the map from the saved data
        :return: (list Tile, list Enemy, list Coin (int, int)): The tile list, the enemies, the coins, and the world size
        """
        tile_list = []
        decor = []
        enemies = []
        coins = []
        answer_inputs = []
        question_pos = (0, 0)
        tile_set = self.level

        # Go through each character in the level data
        for y, row in enumerate(self.level_data):
            for x, char in enumerate(row):
                # Get the position of the current index
                pos = (x * self.tile_size[0] * self.scale, y * self.tile_size[1] * self.scale)

                # Add correct game object depending on character in file
                if char == 'e':
                    enemies.append(Enemy((pos[0], pos[1])))

                elif char == 'b':
                    tile_list.append(Brick(pos, self.scale, tile_set))

                elif char == 'k':
                    tile_list.append(HitBrick(pos, self.scale, BlockCoin, tile_set))

                elif char == 'a':
                    tile_list.append(HitBrick(pos, self.scale, Apple, tile_set))

                elif char == 'q':
                    tile_list.append(QuestionBlock(pos, self.scale, BlockCoin, tile_set))

                elif char == 'p':
                    tile_list.append(QuestionBlock(pos, self.scale, Apple, tile_set))

                elif char == 'c':
                    coins.append(Coin((int(pos[0] + self.tile_size[0] * self.scale / 2),
                                       int(pos[1] + self.tile_size[1] * self.scale / 2))))

                elif char in [str(i) for i in range(7)]:
                    tile_list.append(Tile(pos, int(char), self.scale, tile_set))  # If given a number, return that tile

                elif char == 'z':
                    question_pos = pos

                elif char == 'x':
                    answer_input = AnswerInput(pos, self.scale, tile_set)
                    tile_list.append(answer_input)
                    answer_inputs.append(answer_input)

                elif char == 'l':
                    decor.append(Lava(pos, self.scale))

        return tile_list, enemies, coins, decor, QuestionManager(question_pos, answer_inputs), self.world_size  # Return tiles, enemies, coins, and the world size
