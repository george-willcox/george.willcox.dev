import pygame
from tile import Tile
from tile_getter import TileGetter


class HitBrick(Tile):
    def __init__(self, position, scale, contents, tile_set=0):
        """
        A brick that can be hit
        :param (int, int) position: The position of the brick
        :param int scale: The block's scale
        :param Object contents: The contents of the block
        :param int tile_set: The tile set to use
        """
        super().__init__(position, 7, scale, tile_set)  # Initialise the tile

        self.hit_surface = TileGetter.get_tile(6, scale, tile_set)  # Get the empty block image

        self.velocity = pygame.math.Vector2()  # Create velocity
        self.offset = 0  # Set offset
        self.hit_force = 8  # Set hit force
        self.spring_force = 2  # Set spring force, acts as a retarding force

        self.been_hit = False  # Has the block been hit?

        self.contents = contents  # Reference to the contents class

    def hit(self, sounds):
        """
        Called when hit
        :param dict sounds: Sound effect dict
        :return: None
        """
        sounds['bump'].play()  # Play bump sound
        if not self.been_hit:  # If it hasn't been hit
            self.been_hit = True  # It's been hit
            self.velocity.y = -self.hit_force  # Set y velocity to hit force

        self.surface = self.hit_surface  # Surface become the hit block

    def update(self):
        """
        Update the block
        :return: None
        """
        if self.been_hit:  # Been hit?
            if self.offset <= 0:  # If above where it started
                self.velocity.y += self.spring_force  # Increase velocity by the spring force

                self.offset += self.velocity.y  # Increase the offset by the y velocity

            if self.offset > 0:  # If below where started
                # Set forces, velocity and offset to 0
                self.spring_force = 0
                self.offset = 0
                self.velocity.y = 0

    def render(self, surface, camera):
        """
        Render brick to surface
        :param Surface surface: Surface to blit to
        :param Camera camera: Camera object
        :return: None
        """
        if self.rect.colliderect(camera.rect):  # If on the screen
            surface.blit(self.surface, self.rect.move(-camera.offset, self.offset))  # Blit with offset
