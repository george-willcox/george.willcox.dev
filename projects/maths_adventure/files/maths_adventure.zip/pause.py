import pygame
from pygame.locals import *
from button import Button
from text import Text


class Pause:
    def __init__(self, screen_size, scene_manager):
        """
        Pause menu
        :param (int, int) screen_size: The size of the screen
        :param SceneManager scene_manager: Reference to the scene manager
        """
        self.surface = pygame.Surface((screen_size[0] * 0.75, screen_size[1] * 0.75), flags=SRCALPHA)  # Create surface
        self.rect = self.surface.get_rect(center=(screen_size[0] / 2, screen_size[1] / 2))  # Get rect and set position

        self.surface.fill((0, 0, 0, 128))  # Fill the surface translucent black

        self.paused = False  # Game is not pause by default

        # Created paused text
        self.text = Text((screen_size[0] / 2, screen_size[1] * 0.25), 'PAUSED',
                         (255, 255, 255), 64, 'Fixedsys500c.ttf', 'center')

        # Create pause menu buttons
        menu_rect = (screen_size[0] * 0.25, screen_size[1] * 0.65, screen_size[0] * 0.2, screen_size[1] * 0.1)
        resume_rect = (screen_size[0] * 0.55, screen_size[1] * 0.65, screen_size[0] * 0.2, screen_size[1] * 0.1)
        self.menu = Button(menu_rect, 'MENU', 48, 'Fixedsys500c.ttf', (128, 128, 128), (148, 148, 148),
                           (100, 100, 100), (255, 255, 255), scene_manager.set_scene, 'menu')
        self.resume = Button(resume_rect, 'RESUME', 48, 'Fixedsys500c.ttf',
                             (128, 128, 128), (148, 148, 148), (100, 100, 100), (255, 255, 255), self.toggle)

    def toggle(self):
        """
        Toggle whether the game is pause
        :return: None
        """
        self.paused = not self.paused

    def update(self):
        """
        Update the menu
        :return: None
        """
        if self.paused:  # If paused
            # Update the buttons
            mouse_pos = pygame.mouse.get_pos()
            self.menu.update(mouse_pos)
            self.resume.update(mouse_pos)

    def render(self, surface):
        """
        Render the pause menu
        :param Surface surface: The surface to blit to
        :return: None
        """
        if self.paused:  # Only blit if paused
            # Blit surface, then blit text and buttons
            surface.blit(self.surface, self.rect)
            self.text.render(surface)
            self.menu.render(surface)
            self.resume.render(surface)
