import pygame


class Camera:
    def __init__(self, world_width, screen_size):
        """
        A camera class
        :param int world_width: The total width of the world
        :param (int, int) screen_size: The size of the screen
        """
        self.rect = pygame.Rect(0, 0, *screen_size)  # Set the rect
        self.world_width = world_width  # Set the world width

    def set_world_width(self, world_width):
        """
        Update the world width
        :param int world_width: The width of the world
        :return: None
        """
        self.world_width = world_width  # Set the world width

    def update(self, player):
        """
        Calculates the x offset for the camera
        :param Player player: player object
        :return: None
        """
        if player.rect.centerx < self.rect.width / 2:  # If the player is near the left edge of the world
            self.rect.x = 0  # Offset is zero

        # If player is near the right edge of the world
        elif player.rect.centerx > self.world_width - self.rect.width / 2:
            self.rect.x = self.world_width - self.rect.width  # Set offset to maximum value

        else:  # If the player is somewhere in the middle
            self.rect.x = player.rect.centerx - self.rect.width / 2  # Centre on the player

    @property
    def offset(self):
        """
        Gets the offset
        :return int: The x position of the camera
        """
        return self.rect.x
