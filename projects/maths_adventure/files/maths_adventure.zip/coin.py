import pygame
import os

PATH = 'assets'
IMAGE_PATH = os.path.join(PATH, 'images')


class Coin:
    def __init__(self, position):
        """
        A coin object
        :param (int, int) position: The position of the coin
        """
        master_image = pygame.image.load(os.path.join(IMAGE_PATH, 'coin.png')).convert_alpha()  # Load the coin image

        subsurface_rects = [pygame.Rect(33 * i, 0, 33, 33) for i in range(6)]  # Get the subsurface rects
        self.frames = [master_image.subsurface(rect) for rect in subsurface_rects]  # Get the frames from the master

        self.rect = self.frames[0].get_rect(center=position)  # Set the rect of the coin

        self.frame_number = 0  # Stores the current frame number
        self.y_offset = 0  # The y_offset of the coin, only needed for the block coin
        self.collected = False  # Has the coin been collected?

    def update(self, player, sounds):
        """
        Update the coin
        :param Player player: Reference to the player
        :param dict sounds: The sound dict
        :return: None
        """
        if self.rect.colliderect(player.rect) and not self.collected:  # If player is touching the coin
            self.collected = True  # Mark as collected
            player.add_coin(sounds)  # Play sound effect

    def render(self, surface, camera):
        """
        Render the coin to the surface
        :param Surface surface: The surface to blit to
        :param Camera camera: Reference to the camera
        :return: None
        """
        self.frame_number += 0.22  # Change the frame number
        self.frame_number %= 6  # Loop around back to zero when too big

        if self.rect.colliderect(camera.rect):  # If the coin is on the screen
            # Blit the current frame at the given offset
            surface.blit(self.frames[int(self.frame_number)], self.rect.move(-camera.offset, self.y_offset))
