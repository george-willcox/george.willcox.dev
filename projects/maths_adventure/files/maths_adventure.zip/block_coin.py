from coin import Coin
import pygame


class BlockCoin(Coin):
    def __init__(self, position):
        """
        A coin in a block
        :param (int, int) position: The position of the coin
        """
        super().__init__(position)  # Initialise parent

        self.velocity = pygame.math.Vector2()  # Set velocity
        self.velocity.y = -20
        self.gravity = 2  # Set gravity

    def update(self, *args):  # Update coin
        self.y_offset += self.velocity.y  # Move according to velocity
        self.velocity.y += self.gravity  # Apply gravity
