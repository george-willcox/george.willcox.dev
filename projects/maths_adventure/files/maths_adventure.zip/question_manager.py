import os
from question import Question
from text import Text

PATH = 'assets'
IMAGE_PATH = os.path.join(PATH, 'images')


class QuestionManager:
    def __init__(self, position, answer_inputs):
        """
        A class to manage the maths questions and answer input
        :param (int, int) position: The position of the question text
        :param list AnswerInput answer_inputs: list of references to answer input objects
        """
        # Declare variables
        self.question = None
        self.question_text = None
        self.hide = False

        self.position = position

        self.answer_inputs = answer_inputs
        self.load_question()

        self.sound_played = False

    def load_question(self):
        """
        Load a new question
        :return: None
        """
        self.question = Question()  # Create a new question object

        for i, answer_input in enumerate(self.answer_inputs):  # Update the answer inputs with the new options
            answer_input.reset_value(self.question.options[i])

            if self.hide:  # If hidden, hide the answer inputs
                answer_input.hide = True

        # Get question text
        sym = '+' if self.question.type == 'add' else '-'
        self.question_text = Text(self.position, str(self.question.a) + sym + str(self.question.b) + '=',
                                  (255, 255, 255), 64, 'Fixedsys500c.ttf', anchor='center')

    def update(self, player, sounds):
        """
        Check for input and play sounds
        :param Player player: reference to the player
        :param dict sounds: Sound dictionary
        :return: None
        """
        if not self.hide:  # Only update if not hidden
            for answer_input in self.answer_inputs:
                if answer_input.been_hit and not self.sound_played:  # Play a sound when an input is entered
                    if answer_input.value == self.question.ans:
                        sounds['right'].play()
                        player.can_progress = True

                    else:
                        sounds['wrong'].play()

                if answer_input.reset:  # Once block animation has finished
                    if answer_input.value == self.question.ans:
                        self.hide = True  # If correct, hide the question

                    else:  # If wrong damage the player
                        player.lives -= 1  # Damage player
                        player.invi_frames = player.max_invi_frames  # Show invincibility frames

                    self.load_question()  # Load a new question

    def render(self, surface, camera):
        """
        Render the tile
        :param Surface surface: The surface to blit to
        :param Camera camera:  Camera refernce
        :return: None
        """
        if self.question_text.rect.colliderect(camera.rect) and not self.hide:  # Blit if on the screen
            surface.blit(self.question_text.surface, self.question_text.rect.move(-camera.offset, 24))
