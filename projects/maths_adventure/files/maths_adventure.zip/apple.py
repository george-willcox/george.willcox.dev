import os
import pygame

PATH = 'assets'
IMAGE_PATH = os.path.join(PATH, 'images')


class Apple:
    def __init__(self, position, tile, scale=1.5):
        """
        Apple powerup
        :param (int, int) position: The position of the apple
        :param Tile tile: The tile that spawned the powerup
        :param float scale: The scale of the image
        """
        self.tile = tile  # Keep reference to tile

        self.surface = pygame.image.load(os.path.join(IMAGE_PATH, 'Apple.png')).convert_alpha()  # Load image
        self.surface = pygame.transform.scale(self.surface, (int(self.surface.get_width() * scale),  # Scale image
                                                             int(self.surface.get_height() * scale)))

        self.rect = self.surface.get_rect(center=position)  # Get rect and set position

        self.rise_speed = 2  # The speed it rises out of a block
        self.risen = False  # Has it finished rising?
        self.collected = False  # Has it been collected ?

    def update(self, player, sounds):
        """
        Update the powerup
        :param Player player: Reference to the player
        :param dict sounds: Dict of sounds
        :return: None
        """
        if not self.risen:  # If it hasn't risen yet
            if self.rect.colliderect(self.tile.rect):  # If it's touching the tile that spawned iit
                self.rect.y -= self.rise_speed  # Move up by the rise speed

            else:  # If not touching the spawn tile
                self.rect.bottom = self.tile.rect.top  # Go to directly on top of the tile
                self.risen = True  # It has risen

        elif not self.collected and self.rect.colliderect(player.rect):  # If the player touches it
            sounds['powerup'].play()  # Play sound effect
            self.collected = True  # Has been collected
            player.lives += 1  # Increase player lives

    def render(self, surface, camera):
        """
        Render the apple to the surface
        :param Surface surface: The surface to render to
        :param Camera camera: The camera object
        :return: None
        """
        if not self.collected and self.rect.colliderect(camera.rect):  # If it's on the screen and hasn't been collected
            surface.blit(self.surface, self.rect.move(-camera.offset, 0))  # Blit surface with camera's offset
