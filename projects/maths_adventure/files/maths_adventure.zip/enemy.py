import os
import pygame

PATH = 'assets'
IMAGE_PATH = os.path.join(PATH, 'images')


class Enemy:
    def __init__(self, position, scale=2):
        """
        Enemy class
        :param (int, int) position: The position of the enemy
        :param int scale: The scale of the enemy
        """
        master_image = pygame.image.load(os.path.join(IMAGE_PATH, 'enemy.png')).convert_alpha()  # Load master image
        master_image = pygame.transform.scale(master_image, (master_image.get_width() * scale,  # Scale image
                                                             master_image.get_height() * scale))

        # Get subsurfaces from rects
        subsurface_rects = [pygame.Rect((28 * i) * scale, 0 * scale, 28 * scale, 32 * scale) for i in range(3)]
        self.frames = [master_image.subsurface(rect) for rect in subsurface_rects]

        self.rect = self.frames[0].get_rect(midleft=position)  # Set the enemy's rect

        self.velocity = pygame.math.Vector2()  # Create velocity
        self.velocity.x = -2  # Set velocity to move left
        self.gravity = 1.5  # Set gravity

        self.frame_number = 0  # Current frame number
        self.alive = True  # Is it alive?

        self.death_counter = 10  # How many frames to be squished before disappearing

    def kill(self):
        """
        Mark the enemy as killed
        :return: None
        """
        self.alive = False

    def collide(self, objects):
        """
        Tests for collisions between the enemy and a list of objects with a rect attribute
        :param list Object objects: The list of objects with rect attributes
        :return list Object: The objects collided with
        """
        collisions = []
        for o in objects:  # For each object
            if o.rect.colliderect(self.rect):  # Has it been collided with?
                collisions.append(o)  # Add it to the list

        return collisions
            
    def move(self, tile_list):
        """
        Move the enemy
        :param list Tile tile_list: List of tiles to interact with
        :return: None
        """
        self.rect.x += self.velocity.x  # Update rect with velocity in x direction
        collision = self.collide(tile_list)  # Check for collisions

        if collision:  # If there is a collision
            if self.velocity.x > 0:  # Set the enemies position so that it is on the edge of the object it collided with
                self.rect.right = min(collision, key=lambda x: x.rect.left).rect.left  # Get the furthest left object
            else:
                self.rect.left = max(collision, key=lambda x: x.rect.right).rect.right  # Get the furthest right object

            self.velocity.x *= -1  # Reverse x velocity

        self.velocity.y += self.gravity  # Apply gravity

        self.rect.y += self.velocity.y  # Update rect with velocity in y direction
        collision = self.collide(tile_list)  # Check for collisions

        if collision:  # If there is a collision
            if self.velocity.y > 0:  # Set the enemies position so that it is on the edge of the object it collided with
                self.rect.bottom = min(collision, key=lambda x: x.rect.top).rect.top  # Get the lowest object
            else:
                self.rect.top = max(collision, key=lambda x: x.rect.bottom).rect.bottom  # Get the highest object

            self.velocity.y = 0  # Set y velocity to zero
            
    def update(self, tile_list):
        """
        Update the enemy
        :param list Tile tile_list: The list of tiles to interact with
        :return: None
        """
        self.move(tile_list)  # Call move

        if not self.alive:  # If not alive
            if self.death_counter > 0:
                self.death_counter -= 1  # Decrement death counter

    def render(self, surface, camera):
        """
        Render the enemy
        :param Surface surface: The surface to blit to
        :param Camera camera: The camera object
        :return: None
        """
        if not self.alive:
            self.frame_number = 2  # If killed, set frame to 2
        else:  # Otherwise do animation
            self.frame_number += 0.1  # Increase frame number
            self.frame_number %= 2  # Loop back around if too big

        if self.rect.colliderect(camera.rect) and self.death_counter > 0:  # If on screen
            surface.blit(pygame.transform.flip(self.frames[int(self.frame_number)], self.velocity.x < 0, False),
                         self.rect.move(-camera.offset, 0))  # Blit enemy with given offset
