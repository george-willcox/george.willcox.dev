import os
import pygame

PATH = 'assets'
FONT_PATH = os.path.join(PATH, 'fonts')


class Button:
    def __init__(self, rect, text, font_size, font,
                 normal_colour, hover_colour, active_colour, text_colour, func, *args):
        """
        A button class
        :param (float, float, float, float) rect: The button's rect
        :param str text: The text on the button
        :param int font_size: The size of the font
        :param str font: The name of the font file
        :param (int, int, int) normal_colour: The button's colour
        :param (int, int, int) hover_colour: The colour whilst hovering
        :param (int, int, int) active_colour: The colour when clicked
        :param (int, int, int) text_colour: The colour of the text
        :param func: The function to run when clicked
        :param args: Any arguments to pass to the function
        """
        self.rect = pygame.Rect(rect)  # Set the rect
        self.surface = pygame.Surface(self.rect.size)  # Create a surface

        font_type = pygame.font.Font(os.path.join(FONT_PATH, font), font_size)  # Load the font
        self.text_surface = font_type.render(text, 1, text_colour)  # Create text surface from font

        # Set the text's position
        self.text_rect = self.text_surface.get_rect(center=(self.rect.width / 2, self.rect.height / 2))

        # The colours it can be
        self.colours = {'normal': normal_colour,
                        'hover': hover_colour,
                        'active': active_colour}

        self.colour = 'normal'  # The current state

        self.function = func  # The function
        self.function_args = args  # The function's arguments

        self.update_surface()  # Update the surface

    def update_surface(self):
        """
        Update the surface, fills it in with the correct colour
        :return: None
        """
        self.surface.fill(self.colours[self.colour])  # Fill the surface with the right colour
        self.surface.blit(self.text_surface, self.text_rect)  # Blit the text to the surface

    def update(self, mouse_position):
        """
        Update the button
        :param (int, int) mouse_position: The position of the mouse
        :return: None
        """
        mouse_down = pygame.mouse.get_pressed()[0]  # Get whether the mouse is clicked

        if self.rect.collidepoint(*mouse_position):  # If the mouse is over the button
            if mouse_down:  # If mouse is clicked
                if self.colour != 'active':  # Button has just been clicked
                    self.colour = 'active'  # Set state
                    self.update_surface()  # Update the surface

            else:  # Mouse is not held down
                if self.colour != 'hover':  # Mouse wasn't previously hovering
                    if self.colour == 'active':  # If mouse has just been released over the button
                        self.function(*self.function_args)  # Call function

                    self.colour = 'hover'  # Set the state to hover
                    self.update_surface()  # Update the surface

        else:
            if self.colour != 'normal':  # If the mouse isn't over the button
                self.colour = 'normal'  # Set state to normal
                self.update_surface()  # Update the surface

    def render(self, surface):
        """
        Render the button to the surface
        :param Surface surface: The surface to blit to
        :return: None
        """
        surface.blit(self.surface, self.rect)  # Blit the button to the surface
