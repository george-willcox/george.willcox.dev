import os
import pygame

PATH = 'assets'
IMAGE_PATH = os.path.join(PATH, 'images')


class Lava:
    def __init__(self, position, scale):
        """
        Decorative lava class
        :param (int, int) position: The position of the lava
        :param int scale: The scale of the tile
        """
        image = pygame.image.load(os.path.join(IMAGE_PATH, 'lava.png')).convert_alpha()  # Load surface
        self.surface = pygame.transform.scale(image, (image.get_width() * scale, image.get_height() * scale))
        self.rect = self.surface.get_rect(midleft=position)  # Get rect and set position

    def render(self, surface, camera):
        """
        Render the lava
        :param Surface surface: The surface to blit to
        :param Camera camera:  Camera refernce
        :return: None
        """
        if self.rect.colliderect(camera.rect):  # Blit if on the screen
            surface.blit(self.surface, self.rect.move(-camera.offset, 0))
