import os
import pygame

PATH = 'assets'
SOUND_PATH = os.path.join(PATH, 'sounds')


def load_sounds():
    """
    Loads in the sounds for the game
    :return dict: A dictionary containing all the sounds, referenced by sound name
    """
    sounds = {}
    for sound_name in ['small_jump', 'big_jump', 'brick_smash', 'bump', 'coin', 'stomp', 'powerup', 'death', 'right', 'wrong']:
        sounds[sound_name] = pygame.mixer.Sound(os.path.join(SOUND_PATH, sound_name + '.ogg'))
        sounds[sound_name].set_volume(0.5)  # Set volume to 50%

    return sounds
