import os
import pygame
from pygame.locals import *

PATH = 'assets'
IMAGE_PATH = os.path.join(PATH, 'images')


class Player:
    def __init__(self, scale=2):
        """
        Player class
        :param int scale: The scale of the player's image
        """
        self.scale = scale

        # Load and scale sprite sheet
        master_image = pygame.image.load(os.path.join(IMAGE_PATH, 'Main Character.png')).convert_alpha()
        master_image = pygame.transform.scale(master_image, (master_image.get_width() * scale,
                                                             master_image.get_height() * scale))
        # Get the subsurface rects for the frames
        subsurface_rects = [pygame.Rect((31 + 100 * i) * scale, 18 * scale, 31 * scale, 57 * scale) for i in range(6)]
        self.frames = [master_image.subsurface(rect) for rect in subsurface_rects]

        self.rect = pygame.Rect(0, 0, 31 * scale, 57 * scale)  # Used for displaying image
        self.hitbox = pygame.Rect(0, 0, 19 * scale, 56 * scale)  # Used for collision detection
        self.rect.bottomleft = (96, 577)  # Set the position for the start of the level
        self.hitbox.midbottom = self.rect.move(0, -scale).midbottom  # Move the hitbox to the rect

        self.velocity = pygame.math.Vector2()  # Instantiate velocity

        self.flip = True  # Flag for flipping image in the x direction
        self.jumping = False  # Is the character currently jumping?
        self.frame_number = 0  # keep track of the current frame number for the walk animation

        self.speeds = {'walk': 0.7 * scale, 'run': 1 * scale}  # The multiplier for the walk speed
        self.speed = self.speeds['walk']  # Current speed is walking
        self.jump_force = 28  # The amount of force in a jump
        self.gravity = 1.5  # Set gravity
        self.friction = 0.8  # Set friction

        self.invi_frames = 0  # invincibility frames counter
        self.max_invi_frames = 50  # number of invincibility frames when hit

        # Keep track of lives, coins, and score
        self.lives = 3
        self.coins = 0
        self.score = 0

        self.total_score = 0
        self.total_coins = 0

        self.space_held = False  # Flag for whether the space bar is held

        self.can_progress = False  # Flag for whether the player can go to the next level

    def reset(self, next_level=False):
        """
        Resets the player back to the start of the level
        :return: None
        """
        # Return all attributes to their default values
        self.rect.bottomleft = (96, 577)
        if next_level:
            self.rect.x = 48

        self.hitbox.midbottom = self.rect.move(0, -self.scale).midbottom
        self.velocity = pygame.math.Vector2()
        self.invi_frames = 0
        self.jumping = False
        self.frame_number = 0

    def reset_score(self):
        self.coins = self.total_coins
        self.score = self.total_score

    def clear_score(self):
        self.coins = 0
        self.total_coins = 0
        self.score = 0
        self.total_score = 0
        self.lives = 3

    def next_level(self):
        self.total_coins = self.coins
        self.total_score = self.score
        self.reset(True)

    def collide(self, objects):
        """
        Tests for collisions between the player and a list of objects with a rect attribute
        :param list Object objects: The list of objects with rect attributes
        :return list Object: The objects collided with
        """
        collisions = []
        for o in objects:
            if o.rect.colliderect(self.hitbox):  # If the hitbox collides with the object, add it to the list
                collisions.append(o)

        return collisions

    def movement(self, tile_list, enemies, sounds, world_width):
        """
        Enables player movement
        :param list Tile tile_list: The list of tiles that can be interacted with
        :param list Enemy enemies: The list of enemies that can be interacted with
        :param dict sounds: The sound dict
        :param int world_width: The width of the world
        :return: None
        """
        keys = pygame.key.get_pressed()  # Get pressed keys

        if keys[K_LSHIFT] or keys[K_LCTRL] or keys[K_DOWN] or keys[K_SLASH]:  # If pressing ctrl, shift, or down run
            self.speed = self.speeds['run']
        else:  # Otherwise walk
            self.speed = self.speeds['walk']

        if keys[K_a] or keys[K_LEFT]:  # If left arrow pressed, then decrease x velocity by the speed
            self.velocity.x -= self.speed
            self.flip = False  # Set image orientation

        if keys[K_d] or keys[K_RIGHT]:  # If right arrow pressed, then increase x velocity by the speed
            self.velocity.x += self.speed
            self.flip = True  # Set image orientation

        if keys[K_SPACE] or keys[K_UP]:  # If the space bar or up arrow is pressed
            if not self.space_held:  # And it hasn't been held down
                self.space_held = True  # Mark it as held

                self.hitbox.y += 5  # Move down to check if ground is below feet
                if self.collide(tile_list):  # If touching the ground then jump
                    sounds['small_jump'].play()  # Play jump sound
                    self.jumping = True  # Set jumping flag
                    self.velocity.y = -self.jump_force  # Set y velocity to the jump force

                self.hitbox.y -= 5  # Return to original position

        else:  # If space is not pressed then reset flag
            self.space_held = False

        self.hitbox.x += self.velocity.x  # Move hitbox according to velocity in the x direction
        collisions = self.collide(tile_list)  # Test for collisions

        if collisions:  # If there has been a collision then set position to the edge of the tile
            if self.velocity.x > 0:
                self.hitbox.right = min(collisions, key=lambda x: x.rect.left).rect.left  # Get the furthest left tile
            else:
                self.hitbox.left = max(collisions, key=lambda x: x.rect.right).rect.right  # Get the furthest right tile

            self.velocity.x = 0  # Set x velocity to zero

        # If player touching enemy, damage them
        enemy_collision_x = self.collide(enemies)
        if enemy_collision_x and any([enemy.alive for enemy in enemy_collision_x]):
            if self.invi_frames == 0:  # If they are not invincible
                self.invi_frames = self.max_invi_frames  # Make invincible for short time

                self.lives -= 1  # Damage player

        if self.invi_frames > 0:  # Decrease invincibility timer
            self.invi_frames -= 1

        # Gravity
        self.velocity.y += self.gravity

        self.hitbox.y += self.velocity.y  # Move hitbox according to velocity in y direction
        collisions = self.collide(tile_list)  # Get collisions

        if collisions:  # If there is a collision then go to the edge of the tile
            if self.velocity.y > 0:  # If touching the ground
                self.hitbox.bottom = min(collisions, key=lambda x: x.rect.top).rect.top  # Get highest tile
                self.jumping = False  # No longer jumping
            else:  # If touching ceiling
                self.hitbox.top = max(collisions, key=lambda x: x.rect.bottom).rect.bottom  # Get lowest tile

                for collision in collisions:
                    collision.hit(sounds)  # Call the hit method for tiles hit from below

            self.velocity.y = 0  # Set y velocity to zero

        enemy_collision_y = self.collide(enemies)  # Get enemy collisions in the y direction

        if enemy_collision_y:
            if self.velocity.y > 0:  # Player has landed on enemy
                if any([enemy.alive for enemy in enemy_collision_y]):  # If an enemy is alive then jump
                    if keys[K_SPACE]:  # Jump higher if space is held
                        self.velocity.y = -self.jump_force
                        sounds['big_jump'].play()
                    else:  # Jump less high otherwise
                        sounds['small_jump'].play()
                        self.velocity.y = -self.jump_force / 2

                for enemy in enemy_collision_y:
                    if enemy.alive:  # If enemy is alive and didn't damage player
                        enemy.kill()  # Kill it

                        self.score += 100  # Add score to player
                        sounds['stomp'].play()  # Play stomp sound

        # Friction
        self.velocity.x *= self.friction
        if abs(self.velocity.x) < 0.1:  # Prevents gliding
            self.velocity.x = 0

        if self.hitbox.left < 0:  # Prevents moving of the left edge of the screen
            self.hitbox.left = 0
            self.velocity.x = 0

        if not self.can_progress:
            if self.hitbox.right > world_width:
                self.hitbox.right = world_width
                self.velocity.x = 0

        self.rect.midbottom = self.hitbox.move(0, self.scale).midbottom  # Center rect on hitbox

    def add_coin(self, sounds):
        """
        Add a coin
        :param Sounds sounds: Sound dict
        :return: None
        """
        sounds['coin'].play()  # Play coin effect
        self.coins += 1  # Add coin to player
        self.score += 50  # Increase score

    def update(self, tile_list, enemies, sounds, world_width):
        """
        Update the player
        :param list Tile tile_list: The list of tiles that can be interacted with
        :param list Enemy enemies: The list of enemies that can be interacted with
        :param dict sounds: The sound dict
        :param int world_width: The width of the world
        :return: None
        """
        self.movement(tile_list, enemies, sounds, world_width)  # Call movement method

    def render(self, surface, camera):
        """
        Render the player
        :param Surface surface: Surface to render to
        :param Camera camera: Camera Object
        :return: None
        """
        self.frame_number += self.speed / 10  # Increase the frame number depending on the speed
        self.frame_number %= 4  # Loop back around

        if self.jumping:  # If jumping
            frame = 5  # Set jump frame

        else:
            if abs(self.velocity.x) > 0.1:  # If walking
                frame = int(self.frame_number + 1)  # Set frame according to frame number

            else:  # If standing still, then set still frame
                frame = 0

        if (self.invi_frames + 1) % 3 != 0:  # Flash when invincible
            # Blit player to surface, flip if necessary, and give offset from camera
            surface.blit(pygame.transform.flip(self.frames[frame], self.flip, False), self.rect.move(-camera.offset, 0))
