import os
import pygame

pygame.init()

PATH = 'assets'
IMAGE_PATH = os.path.join(PATH, 'images')


class TileGetter:
    """Class for loading tiles"""
    @classmethod
    def get_tile(cls, tile_number, scale, tile_set=0):
        """
        Load requested tile number
        :param int tile_number: The index of the tile on the tile sheet
        :param int scale: The scale of the tile
        :param int tile_set: The tile set to use
        :return: None
        """
        master_image = pygame.image.load(os.path.join(IMAGE_PATH, 'tile_set_' + str(tile_set) + '.png'))  # Load master image

        subsurface_rect = pygame.Rect(16 * tile_number, 0, 16, 16)  # Get subsurface rect
        converted_image = master_image.convert_alpha()  # Convert master image

        # Get subsurface and scale to size
        return pygame.transform.scale(converted_image.subsurface(subsurface_rect), (subsurface_rect.width * scale,
                                                                                    subsurface_rect.height * scale))
