from tile import Tile
from brick_fragment import BrickFragment


class Brick(Tile):
    def __init__(self, position, scale, tile_set=0):
        """
        A breakable brick
        :param (int, int) position: The position of the brick
        :param int scale: The scale of the image
        :param int tile_set: The tile set to use
        """
        super().__init__(position, 7, scale, tile_set)  # Initialise parent

        self.scale = scale  # Store scale
        self.fragments = []  # Fragments associated with brick

    def hit(self, sounds):
        """
        Called when hit
        :param dict sounds: The dict of sounds
        :return: None
        """
        sounds['brick_smash'].play()  # Play the smash sound effect
        self.remove = True  # Set remove so that the tile is deleted
        # Create the fragments
        self.fragments = [BrickFragment(self.rect.move(offset).topleft, velocity, self.scale) for offset, velocity in
                          [((0, 0), (-4, -20)), ((8, 0), (4, -20)), ((8, 0), (-5, -12)), ((8, 8), (5, -12))]]

