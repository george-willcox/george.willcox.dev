#!/usr/bin/env python

import alsaaudio

m = alsaaudio.Mixer('PCM')
# m = alsaaudio.Mixer('PCM', cardindex=1)


def volume_up():
    vol = m.getvolume()[0]

    vol += 5
    vol = min(vol, 100)

    m.setvolume(vol)


def volume_down():
    vol = m.getvolume()[0]

    vol -= 5
    vol = max(vol, 0)

    m.setvolume(vol)
