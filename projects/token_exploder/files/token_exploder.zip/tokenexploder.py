import os
import sys
import pygame
import random
from random import randint
import time
from classes import text
from subprocess import call
from pygame.locals import *
from ctypes import *

RIGHTPIN = {1: 11, 2: 16}
LEFTPIN = {1: 7, 2: 12}
FIREPIN = {1: 13, 2: 18}
STARTPIN = {1: 15, 2: 22}
CLEARPIN = 29
SHUTDOWNPIN = 31

try:
    import RPi.GPIO as GPIO

    # set up BOARD GPIO numbering
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(RIGHTPIN[1], GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(LEFTPIN[1], GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(FIREPIN[1], GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(STARTPIN[1], GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(RIGHTPIN[2], GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(LEFTPIN[2], GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(FIREPIN[2], GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(STARTPIN[2], GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(CLEARPIN, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
    GPIO.setup(SHUTDOWNPIN, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

    gpio = True

except ImportError:
    gpio = False

pygame.init()
pygame.mixer.pre_init(44100, -16, 1, 4096)

PATH = 'assets'
IMAGEPATH = os.path.join(PATH, 'images')
FONTPATH = os.path.join(PATH, 'fonts')
SOUNDPATH = os.path.join(PATH, 'sounds')

WIDTH = 1920
HEIGHT = 1080
# WIDTH = 960
# HEIGHT =540

Current1 = 0
Current2 = 0
SlowDown = 0
BOMB = 0
startTime = {"1": {"fire": None, "laser": None, "multi": None, "speedUp": None},
             "2": {"fire": None, "laser": None, "multi": None, "speedUp": None},
             "speedDown": None}

windll.user32.SetProcessDPIAware()  # Prevents the screen from overstretching
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT), HWSURFACE | DOUBLEBUF | FULLSCREEN)
# SCREEN = pygame.display.set_mode((WIDTH, HEIGHT), HWSURFACE | DOUBLEBUF )
CLOCK = pygame.time.Clock()
FPS = 60
ICON = pygame.image.load(os.path.join(IMAGEPATH, 'explosion.png')).convert_alpha()
ICON = pygame.transform.scale(ICON, (32, 32))

pygame.display.set_icon(ICON)
pygame.mouse.set_visible(False)
pygame.display.set_caption('TOKENEXPLODER')

#  #------Colours------#  #
BLACK = (0, 0, 0)
LIGHTGREEN = (89, 145, 66)
WHITE = (255, 255, 255)
#  #-------------------#  #

FONT = os.path.join(FONTPATH, 'space_invaders.ttf')
TEXTSIZE = int(7 / 480 * WIDTH)
HIGHSCORESIZE = int(10 / 480 * WIDTH)
TITLESIZE = int(20 / 480 * WIDTH)

fps = FPS


def scale_to_screen(size, default_size=(960, 540), screen_size=(WIDTH, HEIGHT)):
    """
    Scale a surface relative to the screen size
    """
    x = int((size[0] / default_size[0]) * screen_size[0])
    y = int((size[1] / default_size[1]) * screen_size[1])

    return x, y


def read_high_score():
    """
    Reads the high score from 'high scores.dat', creates the file if it doesn't exist.
    :return list: The current high scores
    """
    high_scores = []

    try:
        # Open high scores.dat for reading
        with open('high scores.dat', 'r') as f:
            lines = f.readlines()

            for line in lines:
                score = line.split()
                high_scores.append([score[0], int(score[1])])

    # If high scores.dat does not exist create the file
    except FileNotFoundError:
        # Open high scores.dat for writing
        with open('high scores.dat', 'w'):
            pass

    high_scores.sort(key=lambda l: l[1], reverse=True)

    return high_scores


def write_high_score(high_scores):
    """
    Writes the high scores to 'high scores.dat'
    :return list: The current high scores
    """
    # Sort the scores
    high_scores.sort(key=lambda l: l[1], reverse=True)
    # Only write the top 5
    high_scores = high_scores[:5]

    with open('high scores.dat', 'w') as f:
        for score in high_scores:
            f.write(score[0] + ' ' + str(score[1]) + '\n')

    return high_scores


def load_sounds():
    """
    Loads in the sounds for the game
    :return dict: A dictionary containing all the sounds, referenced by sound name
    """
    sounds = {}
    for sound_name in ['shoot', 'shoot2', 'invaderkilled', 'mysteryentered', 'mysterykilled', 'shipexplosion']:
        sounds[sound_name] = pygame.mixer.Sound(os.path.join(SOUNDPATH, sound_name + '.wav'))
        sounds[sound_name].set_volume(0.2)

    return sounds


class MusicController(object):
    def __init__(self):
        self.music_notes = [pygame.mixer.Sound(os.path.join(SOUNDPATH, str(i) + '.wav')) for i in (0, 1, 2, 3)]

        self.songs = {'game': [self.music_notes[i] for i in [0, 1, 2, 3]],
                      'idle': [self.music_notes[i] for i in [1, 0, 1, 2, 3, 0, 3, 2]]}

        for note in self.music_notes:
            note.set_volume(0.5)

        self.current_note = 0

        self.play_every = 20
        self.tick = 0

    def play_next_note(self, song):
        self.current_note += 1
        self.current_note %= len(self.songs[song])

        note = self.songs[song][self.current_note]
        note.play()

    def play(self, song='idle'):
        if song == 'game':
            self.play_every = 20
        else:
            self.play_every = 35

        self.tick += FPS / fps

        if self.tick >= self.play_every:
            self.tick = 0
            self.play_next_note(song)


class SpriteSheet:
    def __init__(self, filename, cols, rows):
        self.sheet = pygame.image.load(filename).convert_alpha()

        self.cols = cols
        self.rows = rows
        self.totalCellCount = cols * rows

        self.rect = self.sheet.get_rect()
        w = self.cellWidth = self.rect.width / cols
        h = self.cellHeight = self.rect.height / rows
        hw, hh = self.cellCenter = (w / 2, h / 2)

        self.cells = [(index % cols * w, index / cols * h, w, h) for index in range(self.totalCellCount)]
        self.handle = [(0, 0), (-hw, 0), (-w, 0),
                       (0, -hh), (-hw, -hh), (-w, -hh),
                       (0, -h), (-hw, -h), (-w, -h)]

    def update(self, surface, cell_index, x, y, handle=0):
        surface.blit(self.sheet, (x + self.handle[handle][0], y + self.handle[handle][1]), self.cells[cell_index])


class Player(object):
    def __init__(self, player_number):
        """
        The player class
        """
        self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'ship_1.png'))
        self.surface = pygame.transform.scale(self.surface, scale_to_screen((50, 48)))
        self.rect = self.surface.get_rect(center=((WIDTH / 2) - 100, HEIGHT * 0.93))
        self.surface2 = pygame.image.load(os.path.join(IMAGEPATH, 'ship_2.png'))
        self.surface2 = pygame.transform.scale(self.surface2, scale_to_screen((50, 48)))
        self.rect2 = self.surface2.get_rect(center=((WIDTH / 2) + 100, HEIGHT * 0.93))
        # player.1
        self.speed = 3 / 480 * WIDTH
        self.lasers = -1
        self.laser_speed = 7 / 320 * HEIGHT
        self.lives = 3
        self.hidden = False
        self.died = False
        self.score = 0
        self.level = 0
        self.fire_key_down = False
        self.multiplier = 1
        self.shield = 0
        self.speedUp = 1
        self.damage = 10

        # Player.2
        self.speed2 = 3 / 480 * WIDTH
        self.lasers2 = -1
        self.laser_speed2 = 7 / 320 * HEIGHT
        self.lives2 = 3
        self.hidden2 = False
        self.died2 = False
        self.score2 = 0
        self.level2 = 0
        self.fire_key_down2 = False
        self.multiplier2 = 1
        self.shield2 = 0
        self.speedUp2 = 1
        self.damage2 = 10

        self.speedDown = 1
        self.allHidden = False
        self.boss_level = False
        self.double_shot_score = 4000
        self.player_number = player_number
        self.life_given_every = 4000
        self.life_give_counter = 0

    def resetPowerup(self):
        self.speedUp2 = 1
        self.damage2 = 10
        self.multiplier2 = 1
        self.lasers2 = -1
        self.speedUp = 1
        self.damage = 10
        self.multiplier = 1
        self.lasers = -1

    def move(self, laser_group, sounds):
        """
        Move the player using keyboard input or with the GPIO pins
        """
        global startTime
        if startTime["1"]["speedUp"] is not None:
            if (self.speed != 3 / 480 * WIDTH) and (time.time() - startTime["1"]["speedUp"] > 10):
                self.speed = 3 / 480 * WIDTH
        else:
            self.speed = 3 / 480 * WIDTH

        speed = self.speed * FPS / fps

        if gpio:  # GPIO controls
            # Move Left
            if GPIO.input(LEFTPIN[1]):
                if self.rect.left > 0:
                    self.rect.move_ip(-speed, 0)

            # Move Right
            if GPIO.input(RIGHTPIN[1]):
                if self.rect.right < WIDTH:
                    self.rect.move_ip(speed, 0)

            if GPIO.input(FIREPIN[1]):
                if not self.fire_key_down:
                    self.fire(laser_group, sounds)

                    self.fire_key_down = True

            else:
                self.fire_key_down = False

        else:  # Keyboard Controls
            # Get the pressed keys
            keys = pygame.key.get_pressed()

            # Move left
            if keys[K_a] or keys[K_LEFT]:
                if self.rect.left > 0:
                    self.rect.move_ip(-speed, 0)

            # Move right
            if keys[K_d] or keys[K_RIGHT]:
                if self.rect.right < WIDTH:
                    self.rect.move_ip(speed, 0)

            # Fire
            if keys[K_SPACE]:
                if not self.fire_key_down:
                    self.fire(laser_group, sounds)

                    self.fire_key_down = True

            else:
                self.fire_key_down = False

    def move2(self, laser_group, sounds):
        """
        Move the player using keyboard input or with the GPIO pins
        """
        if startTime["2"]["speedUp"] is not None:
            if (self.speed2 != 3 / 480 * WIDTH) and (time.time() - startTime["2"]["speedUp"] > 10):
                self.speed2 = 3 / 480 * WIDTH
        else:
            self.speed2 = 3 / 480 * WIDTH
        speed2 = self.speed2 * FPS / fps

        if gpio:  # GPIO controls
            # Move Left
            if GPIO.input(LEFTPIN[2]):
                if self.rect2.left > 0:
                    self.rect2.move_ip(-speed2, 0)

            # Move Right
            if GPIO.input(RIGHTPIN[2]):
                if self.rect2.right < WIDTH:
                    self.rect2.move_ip(speed2, 0)

            if GPIO.input(FIREPIN[2]):
                if not self.fire_key_down2:
                    self.fire2(laser_group, sounds)

                    self.fire_key_down2 = True

            else:
                self.fire_key_down2 = False

        else:  # Keyboard Controls
            # Get the pressed keys
            keys = pygame.key.get_pressed()

            # Move left
            if keys[K_j]:
                if self.rect2.left > 0:
                    self.rect2.move_ip(-speed2, 0)

            # Move right
            if keys[K_l]:
                if self.rect2.right < WIDTH:
                    self.rect2.move_ip(speed2, 0)

            # Fire
            if keys[K_k]:
                if not self.fire_key_down2:
                    self.fire2(laser_group, sounds)

                    self.fire_key_down2 = True

            else:
                self.fire_key_down2 = False

    def fire(self, laser_group, sounds):
        """
        Creates a new laser instance if one doesn't already exist.
        Player can only fire one laser at a time
        """
        global startTime
        if not self.hidden:
            # if self.lasers == 0:  # Only fire if there are no other lasers from the player on screen
            # If the score is less than the amount required for the double shot ability, fire only one shot

            if startTime["1"]["fire"] is not None:
                if (self.lasers != -1) and time.time() - startTime["1"]["fire"] > 10:
                    self.lasers = -1
                    self.damage = 10
            else:
                self.lasers = -1
                self.damage = 10

            if self.lasers == -1:
                laser_group.add_laser(Laser(self, self.rect.midtop, 1, self.lasers))
            elif self.lasers == 1:
                left_pos = (self.rect.centerx - 0.30 * self.rect.width, self.rect.centery - 0.15 * self.rect.height)
                right_pos = (self.rect.centerx + 0.30 * self.rect.width, self.rect.centery - 0.15 * self.rect.height)
                laser_group.add_laser(Laser(self, left_pos, 1, self.lasers))
                laser_group.add_laser(Laser(self, right_pos, 1, self.lasers))
            elif self.lasers == 2:
                laser_group.add_laser(Laser(self, self.rect.midtop, 1, self.lasers))
            elif self.lasers == 3:
                if startTime["1"]["laser"] is None:
                    startTime["1"]["laser"] = time.time()
                    laser_group.add_laser(Laser(self, self.rect.midtop, 1, self.lasers))
                else:
                    if time.time() - startTime["1"]["laser"] > 3:
                        laser_group.add_laser(Laser(self, self.rect.midtop, 1, self.lasers))
                        startTime["1"]["laser"] = None

            elif self.lasers == 4:
                left_pos = (self.rect.centerx - 0.40 * self.rect.width, self.rect.centery - 0.15 * self.rect.height)
                right_pos = (self.rect.centerx + 0.40 * self.rect.width, self.rect.centery - 0.15 * self.rect.height)
                laser_group.add_laser(Laser(self, left_pos, 1, 4))
                laser_group.add_laser(Laser(self, right_pos, 1, 4))
                laser_group.add_laser(Laser(self, self.rect.midtop, 1, 4))
            elif self.lasers == 5:
                laser_group.add_laser(Laser(self, self.rect.midtop, 1, self.lasers))

            # Play the shooting sound
            sounds['shoot'].stop()
            sounds['shoot'].play()

    def fire2(self, laser_group, sounds):
        """
            Creates a new laser instance if one doesn't already exist.
            Player can only fire one laser at a time
            """
        global startTime
        if not self.hidden2:
            # if self.lasers == 0:  # Only fire if there are no other lasers from the player on screen
            # If the score is less than the amount required for the double shot ability, fire only one shot
            if startTime["2"]["fire"] is not None:
                if (self.lasers2 != -1) and time.time() - startTime["2"]["fire"] > 10:
                    self.lasers2 = -1
                    self.damage2 = 10
            else:
                self.lasers2 = -1
                self.damage2 = 10

            if self.lasers2 == -1:
                laser_group.add_laser(Laser(self, self.rect2.midtop, 2, self.lasers2))
            elif self.lasers2 == 1:
                left_pos = (self.rect2.centerx - 0.30 * self.rect2.width, self.rect2.centery - 0.15 * self.rect2.height)
                right_pos = (self.rect2.centerx + 0.30 * self.rect2.width,
                             self.rect2.centery - 0.15 * self.rect2.height)
                laser_group.add_laser(Laser(self, left_pos, 2, self.lasers2))
                laser_group.add_laser(Laser(self, right_pos, 2, self.lasers2))
            elif self.lasers2 == 2:
                laser_group.add_laser(Laser(self, self.rect2.midtop, 2, self.lasers2))
            elif self.lasers2 == 3:

                if startTime["2"]["laser"] is None:
                    startTime["2"]["laser"] = time.time()
                    laser_group.add_laser(Laser(self, self.rect2.midtop, 1, self.lasers2))
                else:
                    if time.time() - startTime["2"]["laser"] > 3:
                        laser_group.add_laser(Laser(self, self.rect2.midtop, 1, self.lasers2))
                        startTime["2"]["laser"] = None

            elif self.lasers2 == 4:
                left_pos = (self.rect2.centerx - 0.40 * self.rect2.width, self.rect2.centery - 0.15 * self.rect2.height)
                right_pos = (self.rect2.centerx + 0.40 * self.rect2.width,
                             self.rect2.centery - 0.15 * self.rect2.height)
                laser_group.add_laser(Laser(self, left_pos, 2, 4))
                laser_group.add_laser(Laser(self, right_pos, 2, 4))
                laser_group.add_laser(Laser(self, self.rect2.midtop, 2, 4))
            elif self.lasers == 5:
                laser_group.add_laser(Laser(self, self.rect2.midtop, 2, self.lasers2))

            # Play the shooting sound
            sounds['shoot'].stop()
            sounds['shoot'].play()

    def respawn(self):
        """Reset key properties of the player"""
        # Died is set to true so that the game controller knows the player has died
        self.died = True
        self.rect.centerx = (WIDTH / 2) - 100
        self.hidden = False
        self.lasers = -1

    def respawn2(self):
        """Reset key properties of the player"""
        # Died is set to true so that the game controller knows the player has died
        self.died2 = True
        self.rect2.centerx = (WIDTH / 2) + 100
        self.hidden2 = False
        self.lasers2 = -1

    def update(self, laser_group, enemies, explosion_group, sounds):
        """Update the player class"""
        if not self.allHidden:
            # Check for enemy collision
            for enemy in enemies.active_enemies:
                if self.rect.colliderect(enemy.rect):
                    explosion_group.add_explosion(Explosion(self, 0))
                    self.hidden = True
                    self.lives = 0
                elif self.rect2.colliderect(enemy.rect):
                    explosion_group.add_explosion(Explosion(self, 0))
                    self.hidden2 = True
                    self.lives2 = 0

            # Update lives
            if self.score > self.life_given_every + self.life_give_counter:
                self.lives += 1

                if self.lives > 3:
                    self.lives = 3

                self.life_give_counter += self.life_given_every

            if self.score2 > self.life_given_every + self.life_give_counter:
                self.lives2 += 1

                if self.lives2 > 3:
                    self.lives2 = 3

                self.life_give_counter += self.life_given_every

            # Move the player
            self.move(laser_group, sounds)
            self.move2(laser_group, sounds)

            # Blit the player's surface
            index = 0

            if not self.hidden:
                if self.shield == 1:

                    for i in range(1, 4):
                        temp = pygame.image.load(os.path.join(IMAGEPATH, 'transparent.png'))
                        temp = pygame.transform.scale(temp, scale_to_screen((50, 48)))
                        SCREEN.blit(temp, self.rect)
                        SCREEN.blit(self.surface, self.rect)
                        j = randint(1, 3)
                        temp = pygame.image.load(os.path.join(IMAGEPATH, 'Shield/shield_' + str(j) + '.png'))
                        temp = pygame.transform.scale(temp, scale_to_screen((50, 48)))
                        SCREEN.blit(temp, self.rect)

                else:
                    SCREEN.blit(self.surface, self.rect)

            if not self.hidden2:
                if self.shield2 == 1:

                    for i in range(1, 4):
                        temp = pygame.image.load(os.path.join(IMAGEPATH, 'transparent.png'))
                        temp = pygame.transform.scale(temp, scale_to_screen((50, 48)))
                        SCREEN.blit(temp, self.rect2)
                        SCREEN.blit(self.surface2, self.rect2)
                        j = randint(1, 3)
                        temp = pygame.image.load(os.path.join(IMAGEPATH, 'Shield/shield_' + str(j) + '.png'))
                        temp = pygame.transform.scale(temp, scale_to_screen((50, 48)))
                        SCREEN.blit(temp, self.rect2)
                else:
                    SCREEN.blit(self.surface2, self.rect2)


class Enemy(object):  # Uses screen size, not render size
    def __init__(self, position, level, enemy_type):
        """
        The enemy class
        :param position: (x, y) the position of the enemy on the screen
        :param level: int, the current level (1-4)
        :param enemy_type: int, the type of enemy (1-3)
        """
        # Load images
        level_name = 'level ' + str(level)
        image_names = ('enemy' + str(enemy_type) + '_' + str(frame) + '_lvl' + str(level) + '.png' for frame in (1, 2))
        self.frames = [pygame.image.load(os.path.join(IMAGEPATH, level_name, image_name)) for image_name in image_names]

        self.frame = 0

        # Resize to screen size
        for i, frame in enumerate(self.frames):
            self.frames[i] = pygame.transform.scale(frame, scale_to_screen(frame.get_size(), (3840, 2560)))

        self.rect = self.frames[0].get_rect(center=position)
        self.health = 60;

        self.hidden = False

        self.laser_speed = 3 / 320 * HEIGHT

        # Set the value of the enemy when killed
        if (enemy_type - 1) % 3 == 0:
            self.value = 30

        elif (enemy_type - 1) % 3 == 1:
            self.value = 20

        else:
            self.value = 10

    def toggle_frame(self):
        """
        Toggles the current frame
        """
        self.frame += 1
        self.frame %= len(self.frames)

    def render(self):
        """Blit the enemy to the screen"""
        if not self.hidden:
            SCREEN.blit(self.frames[self.frame], self.rect)


class EnemyGroup(object):
    def __init__(self, level, columns=10, move_every=20, move_distance=(6, 16), laser_chance=0.0015):
        """
        A class to load and manage enemies
        :param level: The level number (1-4)
        :param columns: The number of columns of enemies
        :param move_every: How often the enemies should move
        :param move_distance: The distance the enemies should move, both down and to the side
        :param laser_chance: The probability that any given enemy shoots a laser each frame
        """
        layout = (1, 2, 2, 3, 3)
        self.enemies = []
        self.active_enemies = []

        y_position = HEIGHT * 0.15

        # The values to scale the offsets by
        self.x_scaler = 30 / 480 * WIDTH
        self.y_scaler = 24 / 320 * HEIGHT

        for row, enemy_type in enumerate(layout):
            self.enemies.append([])
            for column in range(columns):
                # The x_offset from the centre of the screen
                x_offset = (column + 0.5 - columns / 2) * self.x_scaler

                # The y_offset from the y_position
                y_offset = row * self.y_scaler

                position = (WIDTH / 2 + x_offset, y_position + y_offset)

                enemy = Enemy(position, level, enemy_type)

                self.enemies[row].append(enemy)
                self.active_enemies.append(enemy)

        # The distance the enemy should move, scaled to the screen size
        self._move_distance = (move_distance[0] / 480 * WIDTH, move_distance[1] / 320 * HEIGHT)
        self.backup = move_distance[1] / 320 * HEIGHT
        self.backup = move_distance[1] / 320 * HEIGHT
        self._direction = 1

        # Used to keep track of when to move the enemies
        self._move_every = move_every
        self._tick = 0

        # The indexes of the edges of the group of enemies
        self._left_active_column = 0
        self._right_active_column = len(self.enemies[0]) - 1
        self._bottom_active_row = len(self.enemies) - 1

        self.laser_chance = laser_chance

        # The y coordinate of the bottom of the group of enemies
        self.bottom = 0

    def move_enemies(self):
        # Get the position of the furthest left and right point in the group of enemies
        left = min((self.enemies[row][self._left_active_column].rect.left for row in range(len(self.enemies))))
        right = max((self.enemies[row][self._right_active_column].rect.right for row in range(len(self.enemies))))

        # Find the bottom of the group of enemies
        self.bottom = self.enemies[self._bottom_active_row][0].rect.bottom

        # If the enemies are at the edge of the screen, move them down
        if self._direction == 1:
            if right > WIDTH - self._move_distance[0]:
                self._direction = -1

                self.move_enemies_down()
                return

        elif self._direction == -1:
            if left < self._move_distance[0]:
                self._direction = 1

                self.move_enemies_down()
                return

        # Move all enemies across
        if startTime["speedDown"] != None:
            if SlowDown != 0 and time.time() - startTime["speedDown"] > 10:
                val = self._move_distance[1]
            else:
                val = self._move_distance[1] / 3
        else:
            val = self._move_distance[1]
        for row in self.enemies:
            for enemy in row:
                enemy.toggle_frame()
                enemy.rect.move_ip(val * self._direction, 0)

    def remove_enemy(self, enemy):
        """
        Remove an enemy from the active group
        :param enemy: The enemy to be removed
        """
        enemy.hidden = True
        self.active_enemies.remove(enemy)

        self.find_active_columns()

    def find_active_columns(self):
        """Calculates the indexes of the edges of the group of enemies"""
        columns = len(self.enemies[0])
        rows = len(self.enemies)

        for column in range(columns):
            if any((not self.enemies[row][column].hidden for row in range(rows))):
                self._left_active_column = column
                break

        for column in range(columns - 1, -1, -1):
            if any((not self.enemies[row][column].hidden for row in range(rows))):
                self._right_active_column = column
                break

        for row in range(rows - 1, -1, -1):
            if any((not self.enemies[row][column].hidden for column in range(columns))):
                self._bottom_active_row = row
                break

    def move_enemies_down(self):
        global SlowDown, startTime
        """Move all the enemies down one unit"""
        if startTime["speedDown"] != None:
            if SlowDown != 0 and time.time() - startTime["speedDown"] > 10:
                val = self._move_distance[1]
            else:
                val = self._move_distance[1] / 4
        else:
            val = self._move_distance[1]
        for row in self.enemies:
            for enemy in row:
                enemy.toggle_frame()
                enemy.rect.move_ip(0, val)

    def update(self, laser_group):
        """
        Update the enemy group. Handles movement, firing, and blitting to the screen
        :param laser_group: Reference to the laser group, so that Lasers can be added
        """
        self._tick += FPS / fps

        # Move enemies if ticks is equal to the move delay
        if self._tick >= self._move_every:
            self.move_enemies()
            self._tick = 0

        # Fire Lasers
        for enemy in self.active_enemies:
            if random.random() < self.laser_chance:
                laser_group.add_laser(Laser(enemy))

        # Render Enemies
        for row in self.enemies:
            for enemy in row:
                enemy.render()


class Powerup(object):
    def __init__(self, fired_by):
        self.speed = fired_by.laser_speed
        self.value = randint(0, 11)
        # self.value=3
        self.damage = 10
        if self.value == 0:
            self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'powerup_icons/icons_bomb.png'))
            self.name = "bomb"
            self.damage = 50
        elif self.value == 1:
            self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'powerup_icons/icons_laserDouble.png'))
            self.name = "laserDouble"
            self.damage = 20
        # elif self.value ==2 :
        #    self.surface = pygame.image.load(os.path.join(IMAGEPATH,'powerup_icons/icons_laserStarburst.png'))
        #    self.name = "laserStarburst"
        #    self.damage = 30
        elif self.value == 3:
            self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'powerup_icons/icons_laserThick.png'))
            self.name = "laserThick"
            self.damage = 20
        elif self.value == 4:
            self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'powerup_icons/icons_laserTriple.png'))
            self.name = "laserTriple"
            self.damage = 30
        # elif self.value ==5 :
        #    self.surface = pygame.image.load(os.path.join(IMAGEPATH,'powerup_icons/icons_laserWave.png'))
        #    self.name = "laserWave"
        #   self.damage = 30
        elif self.value == 6:

            self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'powerup_icons/icons_pts2x.png'))
            self.name = "pts2x"
        elif self.value == 7:
            self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'powerup_icons/icons_pts4x.png'))
            self.name = "pts4x"
        elif self.value == 8:
            self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'powerup_icons/icons_pts6x.png'))
            self.name = "pts6X"
        elif self.value == 9:
            self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'powerup_icons/icons_shield.png'))
            self.name = "shield"
        elif self.value == 10:
            self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'powerup_icons/icons_spdDown.png'))
            self.name = "spdDown"
        elif self.value == 11:
            self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'powerup_icons/icons_spdUp.png'))
            self.name = "spdUp"
        else:
            self.value = 1
            self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'powerup_icons/icons_laserDouble.png'))
            self.name = "laserDouble"
            self.damage = 20

        self.surface = pygame.transform.scale(self.surface, scale_to_screen(self.surface.get_size()))
        self.rect = self.surface.get_rect(center=fired_by.rect.center)
        self.fired_by = fired_by

    def update(self):
        """Moves and blits the laser"""
        self.rect.move_ip(0, self.speed * FPS / fps)

        SCREEN.blit(self.surface, self.rect)


class Laser(object):
    def __init__(self, fired_by, position=None, playerNumber=0, option=-1):
        """
        The laser class
        :param fired_by: A reference to the object which fired the laser
        :param position: The spawn position of the laser, if unspecified defaults to the centre
        """
        # Set the speed and the image depending on who fired the laser
        self.laserWave = False
        if isinstance(fired_by, Player):
            if option == -1:
                self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'lasers/laser_single.png'))
            elif option == 1:
                self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'lasers/laser_double.png'))
            elif option == 2:
                self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'lasers/laser_starburst.png'))
            elif option == 3:
                self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'lasers/laser_thick3.png'))
                self.laserWave = True
            elif option == 4:
                self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'lasers/laser_triple.png'))
            elif option == 5:
                self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'lasers/laser_wave.png'))

            else:

                self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'lasers/laser_single.png'))
            self.speed = -fired_by.laser_speed


        elif isinstance(fired_by, Enemy):
            self.speed = fired_by.laser_speed
            self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'enemylaser.png'))

        elif isinstance(fired_by, Boss):
            self.speed = fired_by.laser_speed
            self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'enemylaser.png'))

        else:
            raise Exception('Must pass either a player instance or an enemy instance.')

        # Scale the image depending on the screen size

        self.surface = pygame.transform.scale(self.surface, scale_to_screen(self.surface.get_size()))

        # If the laser was fired by a boss, then its position is random along the width of the boss
        if isinstance(fired_by, Boss):
            position = (random.randint(fired_by.rect.left, fired_by.rect.right), fired_by.rect.bottom)
            self.rect = self.surface.get_rect(center=position)

        else:
            if position is None:
                self.rect = self.surface.get_rect(center=fired_by.rect.center)

            else:
                self.rect = self.surface.get_rect(center=position)

        self.fired_by = fired_by
        self.playerNumber = playerNumber

    def update(self):
        """Moves and blits the laser"""
        self.rect.move_ip(0, self.speed * FPS / fps)
        SCREEN.blit(self.surface, self.rect)


class LaserGroup(object):
    def __init__(self):
        """A class to handle lasers"""
        self.lasers = []
        self.powerups = []
        self.powerUpChance = 0.2

    def add_powerUp(self, powerUp):
        self.powerups.append(powerUp)

    def remove_powerUp(self, powerUp):
        """
        Remove a laser from the group
        :param laser: The laser to be removed
        """
        try:
            self.powerups.remove(powerUp)
        except ValueError:
            pass

    def add_laser(self, laser):
        """
        Add a laser to the group
        :param laser: The laser to be added
        """
        self.lasers.append(laser)

    def remove_laser(self, laser):
        """
        Remove a laser from the group
        :param laser: The laser to be removed
        """
        try:
            self.lasers.remove(laser)
        except ValueError:
            pass

    def remove_all_boss_lasers(self):
        """
        Remove all lasers fired by a boss
        Called at the end of a boss fight
        """
        lasers_to_remove = set()

        # Iterate over all lasers
        for laser in self.lasers:
            # If the laser was fired by a boss remove it
            if isinstance(laser.fired_by, Boss):
                lasers_to_remove.add(laser)

        for laser in lasers_to_remove:
            self.remove_laser(laser)

    def update(self, player, shield_group, enemies, explosion_group, mystery_enemy, sounds):
        global Current1, Current2, startTime, SlowDown, BOMB
        """
        Update all the lasers, requires references to check collisions
        :param player: A reference to the player
        :param shield_group: A reference to the shields
        :param enemies: A reference to the enemies
        :param explosion_group: A reference to the explosions
        :param mystery_enemy: A reference to the mystery enemy
        :param sounds: The sound effects
        :return:
        """
        lasers_to_remove = set()
        powerUp_to_remove = set()
        for power in self.powerups:
            power.update()
            if isinstance(power.fired_by, Enemy):
                if power.rect.colliderect(player.rect):
                    # If the player is not hidden

                    if not player.hidden:

                        powerUp_to_remove.add(power)
                        # Play the shipexplosion sound effect
                        sounds['shipexplosion'].play()

                        if power.value == 0:
                            # player.lasers=0
                            BOMB = 1
                        elif power.value == 1:
                            player.damage = 15
                            player.lasers = 1
                            startTime["1"]["fire"] = time.time()
                        elif power.value == 2:
                            player.damage = 20
                            player.lasers = 2
                            startTime["1"]["fire"] = time.time()
                        elif power.value == 3:
                            player.lasers = 3
                            player.damage = 30
                            startTime["1"]["fire"] = time.time()
                        elif power.value == 4:
                            player.lasers = 4
                            player.damage = 20
                            startTime["1"]["fire"] = time.time()
                        elif power.value == 5:
                            player.lasers = 5
                            player.damage = 30
                            startTime["1"]["fire"] = time.time()
                        elif power.value == 6:
                            player.multiplier = 2
                            startTime["1"]["multi"] = time.time()
                        elif power.value == 7:
                            player.multiplier = 4
                            startTime["1"]["multi"] = time.time()
                        elif power.value == 8:
                            player.multiplier = 6
                            startTime["1"]["multi"] = time.time()
                        elif power.value == 9:
                            player.shield = 1
                        elif power.value == 10:
                            SlowDown = 1
                            startTime["speedDown"] = time.time()
                        elif power.value == 11:
                            player.speed = player.speed * 2
                            startTime["1"]["speedUp"] = time.time()

                    continue
                elif (power.rect.colliderect(player.rect2)):
                    # If the player is not hidden
                    if not player.hidden2:
                        powerUp_to_remove.add(power)

                        sounds['shipexplosion'].play()

                        if power.value == 0:
                            BOMB = 1
                        elif power.value == 1:
                            player.damage2 = 15
                            player.lasers2 = 1
                            startTime["2"]["fire"] = time.time()
                        elif power.value == 2:
                            player.damage2 = 20
                            player.lasers2 = 2
                            startTime["2"]["fire"] = time.time()
                        elif power.value == 3:
                            player.damage2 = 30
                            player.lasers2 = 3
                            startTime["2"]["fire"] = time.time()
                        elif power.value == 4:
                            player.damage2 = 20
                            player.lasers2 = 4
                            startTime["2"]["fire"] = time.time()
                        elif power.value == 5:
                            player.damage2 = 30
                            player.lasers2 = 5
                            startTime["2"]["fire"] = time.time()
                        elif power.value == 6:
                            player.multiplier2 = 2
                            startTime["2"]["multi"] = time.time()
                        elif power.value == 7:
                            player.multiplier2 = 4
                            startTime["2"]["multi"] = time.time()
                        elif power.value == 8:
                            player.multiplier2 = 6
                            startTime["2"]["multi"] = time.time()
                        elif power.value == 9:
                            player.shield2 = 1
                        elif power.value == 10:
                            player.speedDown = player.speedDown / 2
                            startTime["speedDown"] = time.time()
                        elif power.value == 11:
                            player.speed2 = player.speed * 2
                            startTime["2"]["speedUp"] = time.time()
                    continue

        # Iterate over all lasers to check for collisions
        if startTime["1"]["multi"] is not None:
            if (player.multiplier != 1) and (time.time() - startTime["1"]["multi"]) > 10:
                player.multiplier = 1
        else:
            player.multiplier = 1
        if startTime["2"]["multi"] is not None:
            if (player.multiplier2 != 1) and (time.time() - startTime["2"]["multi"]) > 10:
                player.multiplier2 = 1
        else:
            player.multiplier2 = 1
        for laser in self.lasers:
            laser.update()

            # Fired by a player
            if isinstance(laser.fired_by, Player):
                # Check for collisions with other lasers
                for other_laser in self.lasers:
                    if isinstance(other_laser.fired_by, Enemy) or isinstance(other_laser.fired_by, Boss):
                        # If there is a collision, remove both lasers
                        if laser.rect.colliderect(other_laser.rect):
                            lasers_to_remove.add(laser)
                            lasers_to_remove.add(other_laser)

                # Check for collisions with the enemies
                if isinstance(enemies, EnemyGroup):
                    for enemy in enemies.active_enemies:
                        # If there is a collision, remove the enemy and the laser
                        if laser.rect.colliderect(enemy.rect):
                            if laser.playerNumber == 1:
                                enemy.health -= player.damage
                            elif laser.playerNumber == 2:
                                enemy.health -= player.damage2

                            if enemy.health <= 0:
                                enemies.remove_enemy(enemy)
                                # Create an explosion
                                explosion_group.add_explosion(Explosion(enemy, 0))
                                # Play the invaderkilled sound effect
                                sounds['invaderkilled'].play()
                                if random.random() < self.powerUpChance:
                                    self.add_powerUp(Powerup(enemy))
                            if not laser.laserWave:
                                lasers_to_remove.add(laser)

                            # Add the enemy's value to the player's score
                            if laser.playerNumber == 1:
                                player.score += player.multiplier * enemy.value
                            elif laser.playerNumber == 2:
                                player.score2 += player.multiplier2 * enemy.value

                            break

                # Check for collisions with the boss
                elif isinstance(enemies, Boss):
                    # Collision
                    if laser.rect.colliderect(enemies.rect):
                        # Take one away from the boss's health
                        enemies.health -= 1
                        # Remove the laser
                        lasers_to_remove.add(laser)

                        # If the boss runs out of health
                        if enemies.health == 0:
                            # Add its value to the player's score

                            if laser.playerNumber == 1:
                                player.score += player.multiplier * enemies.kill_value
                            elif laser.playerNumber == 2:
                                player.score2 += player.multiplier2 * enemies.kill_value

                            # Create an explosion
                            explosion_group.add_explosion(Explosion(enemies, 0))
                            # Play the explosion sound effect
                            sounds['shipexplosion'].play()

                            # Hide the boss
                            enemies.hidden = True

                            # Remove all of its lasers
                            self.remove_all_boss_lasers()

                        # If the boss still has health
                        else:
                            # Add its hit value to the player's score
                            if laser.playerNumber == 1:
                                player.score += player.multiplier * enemies.hit_value
                            elif laser.playerNumber == 2:
                                player.score2 += player.multiplier2 * enemies.hit_value

                # If there is a mystery enemy, then do collisions
                if mystery_enemy is not None:
                    # Collision
                    if laser.rect.colliderect(mystery_enemy.rect):
                        # Add a random value to the player's score
                        if laser.playerNumber == 1:
                            player.score += player.multiplier * random.choice([25, 50, 100, 150, 300, 500])
                        elif laser.playerNumber == 2:
                            player.score2 += player.multiplier2 * random.choice([25, 50, 100, 150, 300, 500])

                        # Set its hit value to True
                        mystery_enemy.hit = True
                        # Remove the laser
                        lasers_to_remove.add(laser)

                        # Create an explosion
                        explosion_group.add_explosion(Explosion(mystery_enemy, 0))

                        # Play the mysterykilled sound effect and stop the mysteryentered sound effect
                        sounds['mysterykilled'].play()
                        sounds['mysteryentered'].stop()

            # If an enemy fired the laser, check for collisions with the player
            elif isinstance(laser.fired_by, Enemy) or isinstance(laser.fired_by, Boss):
                # Collision
                if laser.rect.colliderect(player.rect):
                    # If the player is not hidden
                    if not player.hidden and player.shield == 0:
                        player.hidden = True
                        # Remove the laser
                        lasers_to_remove.add(laser)

                        # Deduct a life
                        player.lives -= 1

                        # Create an explosion
                        explosion_group.add_explosion(Explosion(player, 1))
                        # Play the shipexplosion sound effect
                        sounds['shipexplosion'].play()
                        Current1 = 1
                    elif player.shield == 1:
                        lasers_to_remove.add(laser)
                        player.shield = 0

                    continue
                elif laser.rect.colliderect(player.rect2):
                    # If the player is not hidden
                    if not player.hidden2 and player.shield2 == 0:
                        player.hidden2 = True
                        # Remove the laser
                        lasers_to_remove.add(laser)

                        # Deduct a life
                        player.lives2 -= 1

                        # Create an explosion
                        explosion_group.add_explosion(Explosion(player, 2))
                        # Play the shipexplosion sound effect
                        sounds['shipexplosion'].play()
                        Current2 = 1
                    elif player.shield2 == 1:
                        lasers_to_remove.add(laser)
                        player.shield2 = 0
                    continue

            shield_tiles_to_remove = set()
            # Check for collisions with the shields
            for shield_tile in shield_group.shield_tiles:
                # Collision
                if laser.rect.colliderect(shield_tile.rect):
                    # Remove the shield tile
                    shield_tiles_to_remove.add(shield_tile)
                    # Remove the laser
                    if (not laser.laserWave):
                        lasers_to_remove.add(laser)

            for shield_tile in shield_tiles_to_remove:
                shield_group.remove_shield_tile(shield_tile)

            # If the laser is off screen remove it
            if laser.rect.bottom < 0 or laser.rect.top > HEIGHT:
                lasers_to_remove.add(laser)

        for laser in lasers_to_remove:
            self.remove_laser(laser)

        for power in powerUp_to_remove:
            self.remove_powerUp(power)


class Explosion(object):
    def __init__(self, instance, playerNumber):
        """
        An explosion
        :param instance: the object which has exploded
        """
        global BOMB
        if isinstance(instance, Player):
            file_name = 'self_explosion.png'

        else:
            file_name = 'explosion.png'
        if BOMB == 1:
            file_name = 'self_explosion.png'
        # Load in the frames
        self.frames = [pygame.image.load(os.path.join(IMAGEPATH, file_name)) for _ in range(2)]

        # Scale the frames to fit the screen
        if isinstance(instance, Boss):
            # If the explosion belongs to a boss, make the explosion bigger
            self.frames[0] = pygame.transform.scale(self.frames[0], scale_to_screen((135, 135)))
            self.frames[1] = pygame.transform.scale(self.frames[1], scale_to_screen((180, 180)))

        elif isinstance(instance, MysteryEnemy):
            # If the explosion belongs to a enemy, make the explosion medium sided
            self.frames[0] = pygame.transform.scale(self.frames[0], scale_to_screen((65, 65)))
            self.frames[1] = pygame.transform.scale(self.frames[1], scale_to_screen((90, 90)))

        else:
            if BOMB == 1:

                self.frames[0] = pygame.transform.scale(self.frames[0], scale_to_screen((90, 90)))
                self.frames[1] = pygame.transform.scale(self.frames[1], scale_to_screen((120, 120)))
                BOMB = 0
            else:
                self.frames[0] = pygame.transform.scale(self.frames[0], scale_to_screen((45, 45)))
                self.frames[1] = pygame.transform.scale(self.frames[1], scale_to_screen((60, 60)))
                BOMB = 0

        self.frames.append(pygame.Surface((1, 1), flags=SRCALPHA))
        if (playerNumber == 1):
            self.rect = self.frames[0].get_rect(center=instance.rect.center)
        elif (playerNumber == 2):
            self.rect = self.frames[0].get_rect(center=instance.rect2.center)
        else:
            self.rect = self.frames[0].get_rect(center=instance.rect.center)

        self.frame = 0
        self.tick = 0
        self.centre = instance.rect.center
        # Set the animation pattern of the explosion depending on what has exploded
        if isinstance(instance, Boss):
            self.delay = [10, 40, 30]
            self.centre = instance.rect.center

        elif isinstance(instance, Player):
            self.delay = [6, 15, 20]
            if (playerNumber == 1):
                self.centre = instance.rect.center
            elif (playerNumber == 2):
                self.centre = instance.rect2.center

        elif isinstance(instance, MysteryEnemy):
            self.delay = [5, 15, 1]
            if (playerNumber == 1):
                self.centre = instance.rect.center
            elif (playerNumber == 2):
                self.centre = instance.rect2.center
        else:
            self.delay = [4, 10, 1]
            if (playerNumber == 1):
                self.centre = instance.rect.center
            elif (playerNumber == 2):
                self.centre = instance.rect2.center

        self.destroyed = False

        self.instance = instance

    def update(self):
        """Update the animation of the explosion and blit the current frame to the screen"""
        self.tick += FPS / fps

        if self.tick >= self.delay[0]:
            self.frame += 1
            self.tick = 0

            if self.frame == 3:
                self.frame = 2
                self.destroyed = True

            else:
                self.delay.pop(0)

        self.rect = self.frames[self.frame].get_rect(center=self.centre)

        SCREEN.blit(self.frames[self.frame], self.rect)


class ExplosionGroup(object):
    def __init__(self):
        """A group to handle explosion"""
        self.explosions = []

    def add_explosion(self, explosion):
        """
        Add an explosion to the group
        :param explosion: The explosion to be added
        """
        self.explosions.append(explosion)

    def remove_explosion(self, explosion):
        """
        Remove an explosion to the group
        :param explosion: The explosion to be removed
        """
        self.explosions.remove(explosion)

    def update(self):
        global Current1, Current2

        """Updates theprin explosions and removes the finished explosions"""

        explosions_to_remove = []

        for explosion in self.explosions:
            explosion.update()

            if explosion.destroyed:
                explosions_to_remove.append(explosion)

        for explosion in explosions_to_remove:
            self.remove_explosion(explosion)

            # If a played died, respawn it
            if isinstance(explosion.instance, Player):
                if (Current1 == 1 and explosion.instance.lives > 0):
                    explosion.instance.respawn()
                    Current1 = 0
                elif (Current2 == 1 and explosion.instance.lives2 > 0):
                    explosion.instance.respawn2()
                    Current2 = 0

            # If a boss died, set its died value to true
            elif isinstance(explosion.instance, Boss):
                explosion.instance.died = True


class ShieldTile(object):
    def __init__(self, position, tile_size, tile):
        """
        An individual shield tile making up the shields
        :param position: The position of the tile
        :param tile_size: The size of the tile
        """
        self.rect = pygame.Rect(position, tile_size)

        # self.surface = pygame.Surface(tile_size)
        # self.surface.fill(LIGHTGREEN)

        if (tile >= 10):
            self.surface = pygame.image.load(os.path.join(IMAGEPATH, 'Barrier2/' + 'image_part_0' + str(tile) + '.png'))
        else:
            self.surface = pygame.image.load(
                os.path.join(IMAGEPATH, 'Barrier2/' + 'image_part_00' + str(tile) + '.png'))
        self.surface = pygame.transform.scale(self.surface, (int(tile_size[0]), int(tile_size[0])))

    def render(self):
        """Blits the surface to the screen"""
        SCREEN.blit(self.surface, self.rect)


class Shields(object):
    def __init__(self):
        """A group to manage the shield tiles"""
        self.shield_tiles = []

        # self.tile_size = (5 / 480 * WIDTH, 5 / 320 * HEIGHT)
        self.tile_size = (7 / 480 * WIDTH, 5 / 320 * HEIGHT)
        # self.grid_size = (10, 5)
        self.grid_size = (7, 7)

        self.reset()

    def reset(self):
        """Reset the shield group"""
        shield_spacing = WIDTH * 0.25
        margin = WIDTH * 0.08
        shield_height = HEIGHT * 0.75

        # Create 4 shields
        for i in range(4):
            self.make_shield((margin + shield_spacing * i, shield_height))

    def make_shield(self, shield_position):
        """
        Create a shield made up of shield tiles
        :param shield_position: The position of the shield
        """
        # Create a grid of tiles
        for x in range(self.grid_size[0]):
            for y in range(self.grid_size[1]):
                # Calculates the position of the tile
                tile_position = (shield_position[0] + self.tile_size[0] * x, shield_position[1] + self.tile_size[1] * y)
                self.shield_tiles.append(
                    ShieldTile(tile_position, (self.tile_size[0] + 1, self.tile_size[1] + 1), (y * 7) + x + 1))

    def remove_shield_tile(self, shield_tile):
        """
        Remove a shield tile
        :param shield_tile: The shield tile to be removed
        """
        if shield_tile in self.shield_tiles:
            self.shield_tiles.remove(shield_tile)

    def update(self, enemies):
        """Blits all the shield tiles to the screen"""
        shield_tiles_to_remove = []

        for tile in self.shield_tiles:
            tile.render()

            for enemy in enemies.active_enemies:
                if tile.rect.colliderect(enemy.rect):
                    shield_tiles_to_remove.append(tile)

        for tile in shield_tiles_to_remove:
            self.remove_shield_tile(tile)


class MysteryEnemy(object):
    def __init__(self, level, sounds):
        """
        A mystery enemy
        :param level: int, The current level (1-4)
        :param sounds: The sound effects
        """
        level_name = 'level ' + str(level)
        image_name = 'mystery_lvl' + str(level)

        # If the level
        if level > 3:
            image_name += random.choice(('-1', '-2', '-3'))

        self.surface = pygame.image.load(os.path.join(IMAGEPATH, level_name, image_name + '.png')).convert_alpha()

        self.surface = pygame.transform.scale(self.surface, scale_to_screen(self.surface.get_size(), (1920, 1280)))
        self.rect = self.surface.get_rect(topright=(0, HEIGHT * 0.05))

        self.speed = 2 / 480 * WIDTH

        self.hit = False

        # Play the mysteryentered sound
        sounds['mysteryentered'].play()

    def update(self, sounds):
        """
        Updates the mystery enemy
        :param sounds: The sound effects
        """
        # Move the mystery enemy
        self.rect.move_ip(self.speed * FPS / fps, 0)
        # Fade out the mystery entered sound
        sounds['mysteryentered'].fadeout(4000)

        SCREEN.blit(self.surface, self.rect)


class Boss(object):
    def __init__(self, level, fire_rate, health):
        """
        A boss enemy
        :param level: int, The current level (1-4)
        :param fire_rate: float, the fire rate of the boss
        :param health: int, how much health it should have
        """
        # Load images
        level_name = 'level ' + str(level)
        image_names = ('boss' + str(level) + '_' + str(frame) + '_lvl' + str(level) + '.png' for frame in (1, 2))
        self.frames = [pygame.image.load(os.path.join(IMAGEPATH, level_name, image_name)) for image_name in image_names]

        self.frames[0] = pygame.transform.scale(self.frames[0],
                                                scale_to_screen(self.frames[0].get_size(), (1800, 1200)))
        self.frames[1] = pygame.transform.scale(self.frames[1],
                                                scale_to_screen(self.frames[1].get_size(), (1800, 1200)))

        self.rect = self.frames[0].get_rect(midtop=(WIDTH / 2, HEIGHT * 0.15))

        self.fire_rate = fire_rate

        self.health = health

        self.hit_value = 5
        self.kill_value = 1000

        self.speed = 2 / 480 * WIDTH
        self.direction = 1

        self.frame = 0
        self.change_every = 20
        self.tick = 0

        self.laser_speed = 3 / 320 * HEIGHT

        self.died = False
        self.hidden = False

    def update(self, laser_group):
        """
        Update the boss
        :param laser_group: A reference to the laser group
        """
        speed = self.speed * FPS / fps
        if not self.hidden:
            self.rect.move_ip(speed * self.direction, 0)

            if self.direction == 1:
                if self.rect.right > WIDTH - 10 * speed:
                    self.direction = -1

            else:
                if self.rect.left < 10 * speed:
                    self.direction = 1

            self.tick += FPS / fps

            if self.tick >= self.change_every:
                self.tick = 0
                self.frame += 1

                self.frame %= 2

            if random.random() < self.fire_rate * FPS / fps:
                laser_group.add_laser(Laser(self))

            SCREEN.blit(self.frames[self.frame], self.rect)


class InitialSelect(object):
    def __init__(self, centre):
        self.centre = centre

        self.letters = []
        self.font_size = int(96 / 480 * WIDTH)
        self.font_type = pygame.font.Font(FONT, self.font_size)

        for letter in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ*=':
            self.letters.append(self.font_type.render(letter, 1, WHITE))

        self.current_position = 0

        self.keys_old = pygame.key.get_pressed()

        self.active_pins = {LEFTPIN[1]: False, RIGHTPIN[1]: False, FIREPIN[1]: False,
                            LEFTPIN[2]: False, RIGHTPIN[2]: False, FIREPIN[2]: False}

    def update(self, player_number):
        keys = pygame.key.get_pressed()

        # If A or LEFT are pressed (and not held down) change the selected character one to the left
        if (keys[K_a] and not self.keys_old[K_a]) or (keys[K_LEFT] and not self.keys_old[K_LEFT]):
            self.current_position -= 1

        # If D or RIGHT are pressed (and not held down) change the selected character one to the right
        if (keys[K_d] and not self.keys_old[K_d]) or (keys[K_RIGHT] and not self.keys_old[K_RIGHT]):
            self.current_position += 1

        # GPIO input
        if gpio:
            if GPIO.input(LEFTPIN[player_number]):
                if not self.active_pins[LEFTPIN[player_number]]:
                    self.current_position -= 1

                self.active_pins[LEFTPIN[player_number]] = True

            else:
                self.active_pins[LEFTPIN[player_number]] = False

            if GPIO.input(RIGHTPIN[player_number]):
                if not self.active_pins[RIGHTPIN[player_number]]:
                    self.current_position += 1

                self.active_pins[RIGHTPIN[player_number]] = True

            else:
                self.active_pins[RIGHTPIN[player_number]] = False

        # Allow the position to wrap around letters
        self.current_position %= len(self.letters)

        # Get the selected letter and two either side to display
        display_letters = []

        for i in range(-2, 3, 1):
            display_letters.append(self.letters[(self.current_position - 1 + i) % len(self.letters)])

        # Scale each letter depending on its location
        for i, scale in enumerate((0.6, 0.8, 1.0, 0.8, 0.6)):
            size = (int(display_letters[i].get_width() * scale), int(display_letters[i].get_height() * scale))
            display_letters[i] = pygame.transform.scale(display_letters[i], size)

        # Set the location of each of the letters
        rects = []

        for i, x_offset in enumerate((-WIDTH / 3, -WIDTH / 6, 0, WIDTH / 6, WIDTH / 3)):
            rects.append(display_letters[i].get_rect(center=(self.centre[0] + x_offset, self.centre[1])))

        # Blit all the letters onto the screen
        for i in range(5):
            SCREEN.blit(display_letters[i], rects[i])

        # If space is pressed (and not held down) return the selected character
        if keys[K_SPACE] and not self.keys_old[K_SPACE]:
            self.keys_old = keys

            return 'ABCDEFGHIJKLMNOPQRSTUVWXYZ*='[self.current_position - 1]

        # GPIO input
        if gpio:
            if GPIO.input(FIREPIN[player_number]):
                if not self.active_pins[FIREPIN[player_number]]:
                    self.active_pins[FIREPIN[player_number]] = True

                    return 'ABCDEFGHIJKLMNOPQRSTUVWXYZ*='[self.current_position - 1]

                self.active_pins[FIREPIN[player_number]] = True

            else:
                self.active_pins[FIREPIN[player_number]] = False

        # save the pressed keys
        self.keys_old = keys


class LifeMeter(object):
    def __init__(self, position, playerNumber):
        self.image = pygame.image.load(os.path.join(IMAGEPATH, 'ship_' + str(playerNumber) + '.png'))

        self.image = pygame.transform.scale(self.image, scale_to_screen((25, 24)))

        self.text = text.Text('Player' + str(playerNumber) + '    LIVES:', position, WHITE, TEXTSIZE, FONT)

        self.position = position

        self.padding = self.image.get_width() * 0.2
        self.spacing = self.image.get_width() + self.padding

        self.y_offset = -HEIGHT * 0.01

    def update(self, lives):
        x_position = self.text.rect.right + self.padding

        for i in range(lives):
            SCREEN.blit(self.image, (x_position + i * self.spacing, self.position[1] + self.y_offset))

        self.text.render(SCREEN)


class ScoreMeter(object):
    def __init__(self, position, playerNumber):
        label_position = position
        self.label = text.Text('SCORE:', label_position, WHITE, TEXTSIZE, FONT)

        score_position = (self.label.rect.right + TEXTSIZE, position[1])
        self.score_text = text.Text(0, score_position, LIGHTGREEN, TEXTSIZE, FONT)

    def update(self, score):
        self.score_text.set_text(str(score))

        self.label.render(SCREEN)
        self.score_text.render(SCREEN)


class TextFlasher(object):
    def __init__(self, string, position, size=TITLESIZE, colour=WHITE):
        self.text = text.Text(string, position, colour, size, FONT, 'center')

        self.hidden = False

        self.flash_every = 50
        self.off_time = 20
        self.tick = 0

        self.flash_counter = 0

    def update(self):
        self.tick += FPS / fps

        if not self.hidden:
            if self.tick >= self.flash_every:
                self.hidden = True

                self.tick = 0

                self.flash_counter += 1

        else:
            if self.tick >= self.off_time:
                self.hidden = False

                self.tick = 0

        if not self.hidden:
            self.text.render(SCREEN)


class TitleScene(object):
    def __init__(self):
        self.title_text = text.Text('TOKENEXPLODER', (WIDTH / 2, HEIGHT / 4), WHITE, TITLESIZE, FONT, 'center')
        self.highscore = text.Text('HIGHSCORE: ', (WIDTH / 2, HEIGHT * 0.35), WHITE, HIGHSCORESIZE, FONT, 'center')

        self.press_start = TextFlasher('PRESS START', (WIDTH / 2, HEIGHT * 0.6), colour=LIGHTGREEN)

        self.players = 1

    def update(self, high_scores):
        if len(high_scores) > 0:
            self.highscore.set_text('HIGHSCORE:', high_scores[0][0], '-', high_scores[0][1])
            self.highscore.render(SCREEN)

        self.title_text.render(SCREEN)
        self.press_start.update()

        keys = pygame.key.get_pressed()

        if keys[K_1]:
            self.players = 1
            return 1

        if keys[K_2]:
            self.players = 2
            return 1

        # GPIO input
        if gpio:
            if GPIO.input(STARTPIN[1]):
                self.players = 1
                return 1

            elif GPIO.input(STARTPIN[2]):
                self.players = 2
                return 1

        return 0


class GameScene(object):
    def __init__(self):
        self.player = {1: Player(1), 2: Player(2)}
        self.enemies = {1: EnemyGroup(1), 2: EnemyGroup(1)}
        self.shields = {1: Shields(), 2: Shields()}
        self.boss = {1: None, 2: None}
        self.mystery = {1: None, 2: None}

        self.lasers = LaserGroup()
        self.explosions = ExplosionGroup()
        self.playing = 2
        self.life_meter = LifeMeter((WIDTH * 0.03, HEIGHT * 0.04), 1)
        self.score_meter = ScoreMeter((WIDTH * 0.3, HEIGHT * 0.04), 1)
        self.life_meter2 = LifeMeter((WIDTH * 0.61, HEIGHT * 0.04), 2)
        self.score_meter2 = ScoreMeter((WIDTH * 0.89, HEIGHT * 0.04), 2)

        self.player_text = {
            1: text.Text('PLAYER 1', (WIDTH * 0.4, HEIGHT * 0.03 + TEXTSIZE), WHITE, TEXTSIZE, FONT, 'center'),
            2: text.Text('PLAYER 2', (WIDTH * 0.4, HEIGHT * 0.03 + TEXTSIZE), WHITE, TEXTSIZE, FONT, 'center')
        }

        self.level_text = [text.Text(string, (WIDTH * 0.5, HEIGHT * 0.03 + TEXTSIZE), WHITE, TEXTSIZE, FONT, 'center')
                           for string in ['Level 1', 'Level 1', 'Level 2', 'Level 2',
                                          'Level 3', 'level 3', 'Level 4', 'Level 4']]

        self.enemy_lose_height = HEIGHT

        self.mystery_spawn_chance = 0.0015

    def reset(self):
        self.player = {1: Player(1), 2: Player(2)}
        fire_rate = 0.0015
        self.enemies = {1: EnemyGroup(self.player[1].level // 2 + 1, laser_chance=fire_rate),
                        2: EnemyGroup(self.player[2].level // 2 + 1, laser_chance=fire_rate)}

        self.shields = {1: Shields(), 2: Shields()}
        self.boss = {1: None, 2: None}
        self.mystery = {1: None, 2: None}

        self.clear_lasers_and_explosions()

    def clear_lasers_and_explosions(self):
        self.lasers = LaserGroup()
        self.explosions = ExplosionGroup()

    def next_level(self, player_number):
        self.clear_lasers_and_explosions()

        # self.player[player_number].respawn()
        self.player[player_number].died = False

        self.player[player_number].level += 1

        if self.player[player_number].level == 8:
            return True

        if self.player[player_number].level % 2 == 1:
            fire_rate = 0.01 * (self.player[player_number].level + 1)
            health = 12 * (self.player[player_number].level + 1)
            self.boss[player_number] = Boss(self.player[player_number].level // 2 + 1, fire_rate, health)

            self.player[player_number].boss_level = True
            self.player[player_number].resetPowerup()



        else:
            self.player[player_number].boss_level = False

            fire_rate = 0.0015 * (self.player[player_number].level + 1)
            # fire_rate = 0.0015
            self.enemies[player_number] = EnemyGroup(self.player[player_number].level // 2 + 1,
                                                     laser_chance=fire_rate)

        self.shields[player_number] = Shields()
        self.mystery[player_number] = None

    def update(self, player_number, sounds):
        self.player[player_number].update(self.lasers, self.enemies[player_number], self.explosions, sounds)

        if ((not self.player[player_number].died) and (self.player[player_number].lives <= 0) and (
        not self.player[player_number].died2) and (self.player[player_number].lives2 <= 0)):
            return "gameOver"
        if self.player[player_number].died:
            self.clear_lasers_and_explosions()
            if self.player[player_number].lives >= 0:
                self.player[player_number].died = False
            return 'Hit'
        if self.player[player_number].died2:
            self.clear_lasers_and_explosions()
            if self.player[player_number].lives2 >= 0:
                self.player[player_number].died2 = False
            return 'Hit2'

        if self.player[player_number].boss_level:
            self.boss[player_number].update(self.lasers)
            self.lasers.update(self.player[player_number], self.shields[player_number], self.boss[player_number],
                               self.explosions, self.mystery[player_number], sounds)

        else:
            self.enemies[player_number].update(self.lasers)
            self.lasers.update(self.player[player_number], self.shields[player_number], self.enemies[player_number],
                               self.explosions, self.mystery[player_number], sounds)

            if self.mystery[player_number] is None:
                if random.random() < self.mystery_spawn_chance:
                    self.mystery[player_number] = MysteryEnemy(self.player[player_number].level // 2 + 1, sounds)

            else:
                self.mystery[player_number].update(sounds)
                if self.mystery[player_number].rect.left > WIDTH or self.mystery[player_number].hit:
                    self.mystery[player_number] = None

        self.shields[player_number].update(self.enemies[player_number])

        self.life_meter.update(self.player[player_number].lives)
        self.score_meter.update(self.player[player_number].score)
        self.life_meter2.update(self.player[player_number].lives2)
        self.score_meter2.update(self.player[player_number].score2)

        if self.player[player_number].boss_level:
            if self.boss[player_number].health <= 0 and self.boss[player_number].died:
                if self.next_level(player_number):
                    return 4

                else:
                    return 1

        else:
            if len(self.enemies[player_number].active_enemies) == 0:
                if self.next_level(player_number):
                    return 4

                else:
                    return 1

            if self.enemies[player_number].bottom > self.enemy_lose_height:
                if self.enemies[player_number].bottom > self.enemy_lose_height:
                    if not self.player[player_number].hidden:
                        self.player[player_number].hidden = True
                        self.explosions.add_explosion(Explosion(self.player[player_number], 1))
                    if not self.player[player_number].hidden2:
                        self.player[player_number].hidden2 = True
                        self.explosions.add_explosion(Explosion(self.player[player_number], 2))

                    self.player[player_number].lives = 0
                    self.player[player_number].lives2 = 0

        self.explosions.update()

        # self.player_text[player_number].render(SCREEN)

        self.level_text[self.player[player_number].level].render(SCREEN)

        return 2


class LevelNumberScene(object):
    def __init__(self):
        self.level_text = None

        self.flashes = 2

        self.text = ['Level 1', 'Warning!', 'Level 2', 'Warning!',
                     'Level 3', 'Warning!', 'Level 4', 'Final Challenge']

    def update(self, level_number):
        if self.level_text is None:
            self.level_text = TextFlasher(self.text[level_number], (WIDTH / 2, HEIGHT / 2))

        self.level_text.update()

        if self.level_text.flash_counter == self.flashes:
            self.level_text = None

            return 2

        else:
            return 1


class GameOverScene(object):
    def __init__(self):
        self.game_over_text = TextFlasher('G A M E   O V E R', (WIDTH / 2, HEIGHT / 2))

        self.flashes = 3

    def update(self):
        self.game_over_text.update()

        if self.game_over_text.flash_counter == self.flashes:
            self.game_over_text.flash_counter = 0

            return 5

        else:
            return 3


class WinScene(object):
    def __init__(self):
        self.win_text = TextFlasher('Y O U   W I N', (WIDTH / 2, HEIGHT / 2))

        self.flashes = 3

    def update(self):
        self.win_text.update()

        if self.win_text.flash_counter == self.flashes:
            self.win_text.flash_counter = 0

            return 5

        else:
            return 4


class ScoreEnterScene(object):
    def __init__(self):
        self.initial_selector = InitialSelect((WIDTH / 2, HEIGHT * 0.6))

        self.initials = ''
        self.name_text = text.Text('ENTER YOUR NAME', (WIDTH / 2, HEIGHT * 0.2), WHITE, HIGHSCORESIZE, FONT, 'center')
        self.initial_text = text.Text(self.initials, (WIDTH / 2, HEIGHT * 0.3), WHITE, TITLESIZE, FONT, 'center')
        self.score_text = text.Text('SCORE', (WIDTH / 2, HEIGHT * 0.8), WHITE, TITLESIZE, FONT, 'center')

        self.player_text = {1: text.Text('PLAYER 1', (WIDTH / 2, HEIGHT * 0.1), WHITE, HIGHSCORESIZE, FONT, 'center'),
                            2: text.Text('PLAYER 2', (WIDTH / 2, HEIGHT * 0.1), WHITE, HIGHSCORESIZE, FONT, 'center')}

        self.max_length = 20

    def update(self, score, player, totalPlayers):
        self.player_text[player].render(SCREEN)
        initial = self.initial_selector.update(player)

        if initial == '=':
            if len(self.initials) > 0:
                return 6


        elif initial == '*':
            self.initials = self.initials[:-1]

        elif initial is not None:
            if len(self.initials) < self.max_length:
                self.initials += initial

        self.initial_text.set_text(self.initials)

        self.initial_text.render(SCREEN)
        self.name_text.render(SCREEN)

        self.score_text.set_text('SCORE', '-', score)
        self.score_text.render(SCREEN)

        if player == 1:
            return 5
        else:
            return 7

    def setIntials(self):
        self.initial_text.set_text(self.initials)

        self.initial_text.render(SCREEN)


class HighScoreScene(object):
    def __init__(self):
        self.high_score_label = text.Text('HIGH SCORES', (WIDTH / 2, HEIGHT * 0.2), WHITE, TITLESIZE, FONT, 'center')
        self.high_score_text = [text.Text('', (WIDTH / 2, height), WHITE, HIGHSCORESIZE, FONT, 'center') for height in
                                range(int(HEIGHT * 0.35), int(HEIGHT * 0.85), int(HEIGHT * 0.1))]

        self.key_down = True

    def set_high_scores(self, high_scores):
        high_scores.sort(key=lambda l: l[1], reverse=True)

        for i, score in enumerate(high_scores):
            self.high_score_text[i].set_text(score[0], '-', str(score[1]))

    def update(self):
        self.high_score_label.render(SCREEN)

        for text in self.high_score_text:
            text.render(SCREEN)

        keys = pygame.key.get_pressed()

        if keys[K_SPACE]:
            if not self.key_down:
                self.key_down = True
                return 0

        else:
            self.key_down = False

        # GPIO input
        if gpio:
            if GPIO.input(FIREPIN[1]) or GPIO.input(FIREPIN[2]):
                return 0

        return 6


let = 0


def main():
    global fps
    high_scores = read_high_score()
    sounds = load_sounds()
    player_number = 1
    scene = 0

    backgrounds = []
    path = os.path.join(IMAGEPATH, 'backgrounds')
    for i in range(9):
        backgrounds.append(pygame.image.load(os.path.join(path, 'background_{}.png'.format(i))).convert())

    title_scene = TitleScene()
    level_number_scene = LevelNumberScene()
    game_scene = GameScene()
    game_over_scene = GameOverScene()
    win_scene = WinScene()
    score_enter_scene = ScoreEnterScene()
    high_score_scene = HighScoreScene()

    high_score_scene.set_high_scores(high_scores)

    music = MusicController()

    scores = {"1": 0, "2": 0}

    while True:
        SCREEN.fill(BLACK)
        start_time = time.time()

        events = pygame.event.get()
        for event in events:
            if event.type == QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    pygame.quit()
                    sys.exit()

        # Clear high scores and shutdown
        if gpio:
            if GPIO.input(CLEARPIN):
                high_scores = write_high_score([])

            if GPIO.input(SHUTDOWNPIN):
                pygame.quit()
                call("sudo shutdown -P now", shell=True)
                sys.exit()

        if scene in (1, 2, 3, 4):
            SCREEN.blit(backgrounds[min(game_scene.player[player_number].level + 1, 8)], (0, 0))

        else:
            SCREEN.blit(backgrounds[0], (0, 0))

        if scene == 0:
            scene = title_scene.update(high_scores)

            if scene == 1:
                players = title_scene.players
                game_scene.reset()



        elif scene == 1:
            scene = level_number_scene.update(game_scene.player[player_number].level)
            if (players == 1):
                game_scene.player[1].lives2 = 0
                game_scene.player[1].hidden2 = True
                game_scene.player[1].died2 = True


        elif scene == 2:
            scene = game_scene.update(1, sounds)
            if scene == 'Hit' or scene == 'Hit2':
                # if players == 1:
                if game_scene.player[1].lives <= 0 and game_scene.player[1].lives2 <= 0:
                    scene = 3
                    game_scene.player[1].allHidden = True
                else:
                    scene = 2
            elif scene == "gameOver":
                scene = 3




        elif scene == 3:
            scene = game_over_scene.update()
            if scene == 5:
                scores["1"] = game_scene.player[1].score
                scores["2"] = game_scene.player[1].score2
                # scores = [[1, game_scene.player[1].score], [2, game_scene.player[1].score2]]
                # scores.sort(key=lambda l: l[1], reverse=True)

        elif scene == 4:
            scene = win_scene.update()

            if scene == 5:
                scores["1"] = game_scene.player[1].score
                scores["2"] = game_scene.player[1].score2

                # scores = [[1, game_scene.player[1].score], [2, game_scene.player[1].score2]]
                scores.sort(key=lambda l: l[1], reverse=True)

        elif scene == 5:
            scene = score_enter_scene.update(scores["1"], 1, players)

            if scene == 6:
                high_scores.append([score_enter_scene.initials, scores["1"]])
                high_scores = write_high_score(high_scores)
                high_score_scene.set_high_scores(high_scores)
                score_enter_scene.initials = ''
                score_enter_scene.setIntials()
                scene = 7
        elif scene == 7:
            if players == 2:
                scene = score_enter_scene.update(scores["2"], 2, players)
                if scene == 6:
                    high_scores.append([score_enter_scene.initials, scores["2"]])
                    high_scores = write_high_score(high_scores)
                    high_score_scene.set_high_scores(high_scores)
                    score_enter_scene.initials = ''
            else:
                scene = 6
        elif scene == 6:
            scene = high_score_scene.update()
        if scene == 2:
            music.play('game')
        else:
            music.play('idle')

        pygame.display.flip()
        CLOCK.tick(FPS)
        fps = 1 / (time.time() - start_time)


if __name__ == '__main__':
    main()
