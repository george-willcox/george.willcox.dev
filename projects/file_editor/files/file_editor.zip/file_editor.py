# 10/04/17
# George Willcox
# Version: 3.7
# File Editor

file_name = input('Enter the name of the file: ')

print('Choose mode to open file:')

while True:
    mode = input('Read (r); OverWrite (w); Append (a); Write New (x) ')
    if mode in ('r', 'w', 'x'):
        break
    elif mode == 'a':
        mode = 'r+'
        break
    else:
        print ('Invalid')

try:
    with open(file_name, mode) as file:
        if mode != 'r': print('Enter message: ', end = '')

        if mode == 'r': print(file.read())

        elif mode == 'r+':
            file_contents = file.read()
            message = input('\n' + file_contents)
            file.write(message)
            print(file_contents + message)
            
        elif mode in ('w', 'x'):
            message = input()
            file.write(message)
            print(message)

except FileExistsError:
    print('File already exists')

except FileNotFoundError:
    print('File could not be found')
