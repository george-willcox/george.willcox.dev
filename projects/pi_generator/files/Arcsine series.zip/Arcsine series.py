#Uses the decimal module to allow more decimal places
import decimal

#Asks how many decimal places to calculate
places = int(input('\nHow many decimal places of pi would you like to calulate: ')) + 1
#Set the number of decimal places
decimal.getcontext().prec = places

#Define some varibles to be used in the calculation
n = 0
last = 0

#The first term in the secquence is 1/2 so value is set to this
value = decimal.Decimal(1 / 2)

while True:
    n += 1
    top = 1
    bottom = 2 ** (2 * n + 1) * (2 * n + 1) * 2
    for i in range(n):
        top *= 2 * i + 1
        if i != 0: bottom *= 2 * i + 2
        
    value += decimal.Decimal(top) / decimal.Decimal(bottom)

    #Test if the value is the same as the last value calculated
    if value == last:
        print('\n\nThe sequence found pi to', places - 1, 'decimal places after', n, 'iterations\n')
        print(value * 6)
        break
    else:
        print(value * 6)
        last = value

#Stops the program from automatically ending
input()
