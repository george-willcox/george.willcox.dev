#Define varibles needed for the sum
n = 0
value = 0

while True:
    value += 1 / (2 * n + 1)
    n += 1
    value -= 1 / (2 * n + 1)
    n += 1

    print(value * 4)
