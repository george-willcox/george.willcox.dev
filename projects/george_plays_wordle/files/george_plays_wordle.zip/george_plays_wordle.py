from concurrent.futures import ThreadPoolExecutor
from functools import wraps
import random
import pygame
import sys
import os
from pygame import locals
from pygame import gfxdraw

pygame.init()
WIDTH = 500
HEIGHT = 500
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("George Plays Wordle")
CLOCK = pygame.time.Clock()
FPS = 60

GREEN = (106, 170, 100)
YELLOW = (201, 180, 88)
GREY = (134, 136, 138)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
LIGHTGREY = (216, 216, 216)
CLEAR = (0, 0, 0, 0)

done_loading = True
target_string = ""

_DEFAULT_POOL = ThreadPoolExecutor()


def threadpool(f, executor=None):
    @wraps(f)
    def wrap(*args, **kwargs):
        return (executor or _DEFAULT_POOL).submit(f, *args, **kwargs)

    return wrap


def draw_rect(rect, colour, radius=0, surface=SCREEN):
    """Can draw a rectangle with corners that are rounded to a given radius"""
    pointlist = ((rect[0] + radius, rect[1]), (rect[0] + rect[2] - radius, rect[1]),
                    (rect[0] + rect[2], rect[1] + radius), (rect[0] + rect[2], rect[1] + rect[3] - radius),
                    (rect[0] + rect[2] - radius, rect[1] + rect[3]), (rect[0] + radius, rect[1] + rect[3]),
                    (rect[0], rect[1] + rect[3] - radius), (rect[0], rect[1] + radius))
    pygame.draw.polygon(surface, colour, pointlist)

    for x, y in ((rect[0] + radius, rect[1] + radius),
                    (rect[0] + rect[2] - radius - 1, rect[1] + radius),
                    (rect[0] + rect[2] - radius - 1, rect[1] + rect[3] - radius - 1),
                    (rect[0] + radius, rect[1] + rect[3] - radius - 1)):
        gfxdraw.aacircle(surface, x, y, radius, colour)
        gfxdraw.filled_circle(surface, x, y, radius, colour)


def generate_words(allowed_words, all_words, max_green=1, max_yellow=2, number_of_guesses=3):
    global target_string
    
    while True:
        words = [word.strip("\n").upper()
                 for word in random.sample(allowed_words, number_of_guesses + 1)]
        #words = ["WHOLE", "UNFIT", "SWEAT", "MYRRH"]
        guesses = words[:-1]
        target = words[-1]

        green = "-" * len(target)
        yellow = {letter: [0] * number_of_guesses for letter in target}
        grey = []
        colours = [[0] * len(target) for i in range(number_of_guesses)]

        for i, guess in enumerate(guesses):
            count = {}
            for letter in target:
                if letter in count:
                    count[letter] += 1
                else:
                    count[letter] = 1

            for j, letter in enumerate(guess):
                if letter == target[j]:
                    green = green[:j] + letter + green[j + 1:]
                    count[letter] -= 1
                    colours[i][j] = GREEN
            
            for j, letter in enumerate(guess):
                if letter in count and count[letter] > 0 and letter != target[j]:
                    count[letter] -= 1
                    yellow[letter][i] += 1
                    colours[i][j] = YELLOW
                elif letter not in yellow and letter not in grey:
                    grey.append(letter)
                if colours[i][j] == 0:
                    colours[i][j] = GREY

        yellow = {letter: max(number) for letter, number in yellow.items()}

        if not(len(green.replace("-", "")) <= max_green and sum(yellow.values()) <= max_yellow):
            continue

        matches = []
        for word in all_words:
            word = word.upper()
            skip = False

            for letter in word:
                if letter in grey:
                    skip = True
                    break
            if skip: continue

            for i, letter in enumerate(green):
                if letter != word[i] and letter != "-":
                    skip = True
                    break
            if skip: continue
            
            for letter, number in yellow.items():
                if len(word) - len(word.replace(letter, "")) < number:
                    skip = True
                    break
            if skip: continue
            
            matches.append(word)

        if len(matches) == 1:
            break
    
    target_string = target
    return guesses, target, colours, green, yellow, grey


def create_surfaces(guesses, target, colours, green, yellow, grey):
    number_of_guesses = len(guesses)
    padding = 5
    size = [min((WIDTH - 50) // len(target) - padding, 50),
            min((HEIGHT // 2 - 45) // number_of_guesses - padding, 50)]

    squares = [[(pygame.Surface(size), pygame.Rect(
                 (WIDTH - size[0]) / 2 + ((x + ((len(target) + 1) % 2 / 2)) * (size[0] + padding)),
                 HEIGHT / 4 + ((y + ((number_of_guesses + 1) % 2 / 2)) * (size[1] + padding)) - size[1] // 2, size[0], size[1]))
                for x in range(-(len(target) // 2), -(-len(target) // 2))]
                for y in range(-(number_of_guesses // 2), -(-number_of_guesses // 2))]
    
    font_type = pygame.font.SysFont("consolas", min(size))
    for y, row in enumerate(colours):
        for x, colour in enumerate(row):
            squares[y][x][0].fill(colour)
            
            surface = font_type.render(guesses[y][x], 1, WHITE)
            rect = surface.get_rect(center=(size[0]//2, size[1]//2 + 2))
            squares[y][x][0].blit(surface, rect)

    target_word_surface = pygame.font.SysFont("consolas", size[0]).render(" ".join(target), 1, BLACK)
    target_word_rect = target_word_surface.get_rect(center=(WIDTH / 2, 270))
    target_word = (target_word_surface, target_word_rect)

    layout = ["QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"]
    size = (35, 45)
    keyboard_squares = [[(pygame.Surface(size),
                          pygame.Rect((WIDTH - size[0]) / 2 + ((x + ((len(row) + 1) % 2 / 2)) * (size[0] + 9)),
                          320 + (y * (size[1] + 9)), size[0], size[1]))
                          for x in range(-(len(row) // 2), -(-len(row) // 2))]
                        for y, row in enumerate(layout)]

    font_type = pygame.font.SysFont("consolas", 25)

    for y, row in enumerate(layout):
        for x, letter in enumerate(row):
            keyboard_squares[y][x][0].fill(WHITE)
            letter_colour = WHITE
            if letter in green:
                draw_rect((0, 0, size[0], size[1]), GREEN, 5, keyboard_squares[y][x][0])
            elif letter in yellow and yellow[letter] >= 1:
                draw_rect((0, 0, size[0], size[1]), YELLOW, 5, keyboard_squares[y][x][0])
            elif letter in grey:
                draw_rect((0, 0, size[0], size[1]), GREY, 5, keyboard_squares[y][x][0])
            else:
                draw_rect((0, 0, size[0], size[1]), LIGHTGREY, 5, keyboard_squares[y][x][0])
                letter_colour = BLACK

            surface = font_type.render(letter, 1, letter_colour)
            rect = surface.get_rect(center=(size[0]//2, size[1]//2 + 2))
            keyboard_squares[y][x][0].blit(surface, rect)

    return squares + keyboard_squares, target_word


@threadpool
def new_puzzle(words, all_words):
    global done_loading
    done_loading = False
    return_data = create_surfaces(*generate_words(words, all_words, 1, 3))
    done_loading = True
    return return_data


class LoadingCircle:
    def __init__(self, position, size=50, width=5) -> None:
        self.surface = pygame.Surface((size, size)).convert_alpha()
        self.surface.fill(CLEAR)
        gfxdraw.aacircle(self.surface, int(size//2), int(size//2), int(size//2) - 1, GREY)
        gfxdraw.filled_circle(self.surface, int(size//2), int(size//2), int(size//2) - 1, GREY)
        gfxdraw.filled_circle(self.surface, int(size//2), int(size//2), int(size//2) - width - 1, CLEAR)
        pygame.draw.polygon(self.surface, CLEAR, [(int(size//2), int(size//2)), (int(size//2), 0), (size, 0), (size, size//2)])
        
        self.position = int(position[0]), int(position[1])
        self.angle = 0
        self.speed = 15
        self.image = pygame.transform.rotate(self.surface, self.angle)
        self.rect = self.image.get_rect(center=self.position)
        
    def set_position(self, position):
        self.position = int(position[0]), int(position[1])
        
    def draw(self, surface):
        self.angle = (self.angle - self.speed) % 360
        self.image = pygame.transform.rotate(self.surface, self.angle)
        self.rect = self.image.get_rect(center=self.position)
        surface.blit(self.image, self.rect)


def main():
    word_length = 5
    with open("frequent_words.txt", "r") as f:
        words = list(filter(lambda x: len(x) == word_length + 1, f.readlines()))

    with open("dictionary.txt", "r") as f:
        all_words = list(filter(lambda x: len(x) == word_length + 1, f.readlines()))

    puzzle = new_puzzle(words, all_words)
    
    started = False
    loading = True
    loading_circle = LoadingCircle((WIDTH / 2, HEIGHT / 2))
    
    while True:
        events = pygame.event.get()
        for event in events:
            if event.type == locals.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == locals.KEYDOWN:
                if event.key == locals.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                if (event.key == locals.K_r or event.key == locals.K_RETURN) and not loading:
                    puzzle = new_puzzle(words, all_words)
                    loading = True
                if event.key == locals.K_i and started:
                    pygame.image.save(SCREEN, os.path.join("screenshots", f"{target_string}.png"))

        if done_loading and loading:
            if not started:
                started = True
                loading_circle.set_position((WIDTH / 10, HEIGHT / 2))
            loading = False
            squares, target_word = puzzle.result()

        SCREEN.fill((255, 255, 255))

        if started:
            for row in squares:
                for square in row:
                    SCREEN.blit(*square)

            keys = pygame.key.get_pressed()
            if keys[locals.K_SPACE] or loading:
                SCREEN.blit(*target_word)

        if loading:
            loading_circle.draw(SCREEN)

        pygame.display.update()
        CLOCK.tick(FPS)


if __name__ == '__main__':
    main()
