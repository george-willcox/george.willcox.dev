# 10/04/17
# George Willcox
# Version: 3.7
# File Editor

import math

num = int(input("Enter a number: "))

#Prime numbers are greater than 1
if num > 1:
    
    #Check for factors from 2 to sqrt num
    for i in range(2, math.ceil(math.sqrt(num))):
        
        #If num is divisible by i it is not prime
        if num % i == 0:
            print(num, 'is not a prime number')
            print(i, 'times', int(num / i), 'is', num)
            break
        
    else:
        print(num, 'is a prime number')

#If input number is less than or equal to 1, it is not prime
else:
    print(num, 'is not a prime number')
